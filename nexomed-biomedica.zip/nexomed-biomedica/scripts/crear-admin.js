// Crea o reemplaza la cuenta de administración del panel.
//
//   npm run admin:crear                  -> pregunta usuario y contraseña
//   npm run admin:crear -- --imprimir    -> no guarda archivo; imprime las variables
//                                           ADMIN_USERNAME y ADMIN_PASSWORD_HASH para el hosting
//
// Sin interacción (p. ej. en un servidor): ADMIN_USERNAME y ADMIN_PASSWORD como variables de entorno.
import fs from 'node:fs';
import readline from 'node:readline';
import { ADMIN_FILE } from '../server/config.js';
import { hashPassword } from '../server/auth.js';

const printOnly = process.argv.includes('--imprimir');

function ask(question, hidden = false) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    let muted = false;
    rl._writeToOutput = (s) => {
      if (!muted) rl.output.write(s);
    };
    rl.question(question, (answer) => {
      rl.close();
      if (hidden) process.stdout.write('\n');
      resolve(answer);
    });
    muted = hidden;
  });
}

function fail(message) {
  console.error(`Error: ${message}`);
  process.exit(1);
}

const username = (process.env.ADMIN_USERNAME || (await ask('Usuario administrador: '))).trim().toLowerCase();
if (!/^[a-z0-9._-]{3,40}$/.test(username)) {
  fail('El usuario debe tener de 3 a 40 caracteres: letras sin acentos, números, punto, guion o guion bajo.');
}

let password = process.env.ADMIN_PASSWORD;
if (!password) {
  password = await ask('Contraseña (mínimo 12 caracteres): ', true);
  const again = await ask('Repite la contraseña: ', true);
  if (password !== again) fail('Las contraseñas no coinciden.');
}
if (password.length < 12) fail('La contraseña debe tener al menos 12 caracteres.');
if (password.length > 256) fail('La contraseña es demasiado larga.');
if (password.toLowerCase().includes(username) || /^(.)\1+$/.test(password)) {
  fail('La contraseña es demasiado predecible. Usa una frase larga y única.');
}

const passwordHash = await hashPassword(password);

if (printOnly) {
  console.log('\nConfigura estas variables de entorno en tu hosting:\n');
  console.log(`ADMIN_USERNAME=${username}`);
  console.log(`ADMIN_PASSWORD_HASH=${passwordHash}\n`);
} else {
  fs.writeFileSync(ADMIN_FILE, JSON.stringify({ username, passwordHash, updatedAt: new Date().toISOString() }, null, 2), {
    mode: 0o600,
  });
  console.log(`\nAdministrador «${username}» guardado en ${ADMIN_FILE}.`);
  console.log('Las sesiones abiertas anteriormente quedaron invalidadas.');
}
