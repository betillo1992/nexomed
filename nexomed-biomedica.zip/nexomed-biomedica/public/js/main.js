// Interactividad del sitio público. El contenido llega renderizado desde el
// servidor; aquí solo se añaden menú, búsqueda, filtros y efectos sutiles.
import { icon } from './icons.js';
import { normalize } from './templates.js';
import { waLink, messages } from './whatsapp.js';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/* ---------- Encabezado y menú móvil ---------- */
const header = $('.site-header');
const toggle = $('.menu-toggle');
const menu = $('#mobile-menu');

const onScroll = () => header?.classList.toggle('is-scrolled', window.scrollY > 8);
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();

function setMenu(open) {
  if (!toggle || !menu) return;
  toggle.setAttribute('aria-expanded', String(open));
  toggle.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
  toggle.innerHTML = icon(open ? 'x' : 'menu');
  menu.hidden = !open;
  document.body.classList.toggle('menu-open', open);
}

toggle?.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
menu?.addEventListener('click', (e) => {
  if (e.target.closest('a')) setMenu(false);
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && toggle?.getAttribute('aria-expanded') === 'true') {
    setMenu(false);
    toggle.focus();
  }
});
window.matchMedia('(min-width: 1181px)').addEventListener('change', (e) => {
  if (e.matches) setMenu(false);
});

/* ---------- Catálogo: búsqueda y filtros ---------- */
const catalog = $('#catalogo');

if (catalog) {
  const input = $('#catalog-search');
  const clearBtn = $('.search-clear');
  const chips = $$('[data-filter]', catalog);
  const groups = $$('.cat-group', catalog);
  const status = $('#catalog-status');
  const empty = $('#catalog-empty');
  const emptyWa = $('#catalog-empty-wa');
  const number = catalog.dataset.wa;
  let filter = 'all';

  const chipLabel = (chip) => chip.firstChild.textContent.trim();
  const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

  function apply() {
    const raw = input.value.trim();
    const words = normalize(raw).split(' ').filter(Boolean);
    let total = 0;

    for (const group of groups) {
      const inCategory = filter === 'all' || group.dataset.cat === filter;
      let visible = 0;
      for (const card of $$('.item-card', group)) {
        const match = inCategory && words.every((w) => card.dataset.search.includes(w));
        card.hidden = !match;
        if (match) visible++;
      }
      group.hidden = !inCategory || (words.length > 0 && visible === 0);
      total += visible;
    }

    clearBtn.hidden = !raw;
    empty.hidden = !(words.length && total === 0);
    if (words.length && total === 0) emptyWa.href = waLink(number, messages.search(raw));

    const scope = filter === 'all' ? '' : ` en ${chipLabel(chips.find((c) => c.dataset.filter === filter))}`;
    status.textContent = words.length
      ? `${plural(total, 'resultado', 'resultados')} para «${raw}»${scope}`
      : `${plural(total, 'producto o servicio', 'productos y servicios')}${scope}`;
  }

  function setFilter(value) {
    filter = value;
    for (const chip of chips) {
      const active = chip.dataset.filter === value;
      chip.classList.toggle('is-active', active);
      chip.setAttribute('aria-pressed', String(active));
    }
    apply();
  }

  function reset() {
    input.value = '';
    setFilter('all');
  }

  let timer;
  input.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(apply, 80);
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && input.value) {
      e.stopPropagation();
      input.value = '';
      apply();
    }
  });
  clearBtn.addEventListener('click', () => {
    input.value = '';
    apply();
    input.focus();
  });
  for (const chip of chips) chip.addEventListener('click', () => setFilter(chip.dataset.filter));
  $('#catalog-reset').addEventListener('click', reset);

  // Los enlaces a una categoría (menú, tarjetas, pie) siempre deben mostrarla.
  document.addEventListener('click', (e) => {
    const link = e.target.closest('a[href*="#cat-"]');
    if (link && (filter !== 'all' || input.value)) reset();
  });

  apply();
}

/* ---------- Sección activa en el menú ---------- */
const navLinks = $$('.nav-link[data-nav]');
const sections = [$('#inicio'), ...$$('.cat-group')].filter(Boolean);

if (navLinks.length && sections.length && 'IntersectionObserver' in window) {
  const setActive = (key) => {
    for (const link of navLinks) {
      if (link.dataset.nav === key) link.setAttribute('aria-current', 'true');
      else link.removeAttribute('aria-current');
    }
  };
  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) setActive(entry.target.id === 'inicio' ? 'inicio' : entry.target.dataset.cat);
      }
    },
    { rootMargin: '-40% 0px -55% 0px' }
  );
  sections.forEach((s) => observer.observe(s));
}

/* ---------- Aparición sutil al hacer scroll ---------- */
const reveals = $$('.reveal');
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

if (reveals.length && !reduceMotion && 'IntersectionObserver' in window) {
  // Lo que ya está en pantalla se muestra de inmediato, sin parpadeo.
  for (const el of reveals) {
    if (el.getBoundingClientRect().top < window.innerHeight) el.classList.add('is-visible');
  }
  document.documentElement.classList.add('js');
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry, i) => {
        if (!entry.isIntersecting) return;
        entry.target.style.transitionDelay = `${Math.min(i, 4) * 60}ms`;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    },
    { rootMargin: '0px 0px -8% 0px' }
  );
  reveals.filter((el) => !el.classList.contains('is-visible')).forEach((el) => observer.observe(el));
}
