// Plantillas HTML del sitio público. Se usan en el servidor para el renderizado
// inicial (SEO y rendimiento); el navegador solo añade interactividad.
import { icon, brandIcon } from './icons.js';
import { waLink, messages } from './whatsapp.js';

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (value = '') => String(value).replace(/[&<>"']/g, (c) => ESC[c]);

export const normalize = (value) =>
  String(value || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();

export const anchorId = (cat) => `cat-${cat.slug}`;

const NEW_TAB = 'target="_blank" rel="noopener noreferrer"';

export const SOCIAL_NETWORKS = [
  { key: 'facebook', label: 'Facebook' },
  { key: 'instagram', label: 'Instagram' },
  { key: 'tiktok', label: 'TikTok' },
];

export function brand(variant = '') {
  return `<a class="brand ${variant}" href="/#inicio" aria-label="Nexomed Biomédica, ir al inicio">
    <span class="brand-top">NEXOMED</span><span class="brand-main">BIOMÉDICA</span>
  </a>`;
}

function waButton({ number, message, label, cls = 'btn btn-primary', ariaLabel }) {
  const aria = ariaLabel ? ` aria-label="${esc(ariaLabel)}"` : '';
  return `<a class="${cls}" href="${esc(waLink(number, message))}" ${NEW_TAB}${aria}>${brandIcon('whatsapp')}<span>${esc(label)}</span></a>`;
}

export function header(ctx) {
  const links = [
    `<li><a class="nav-link" href="/#inicio" data-nav="inicio">Inicio</a></li>`,
    ...ctx.categories.map(
      (c) => `<li><a class="nav-link" href="/#${anchorId(c)}" data-nav="${esc(c.slug)}">${esc(c.shortName)}</a></li>`
    ),
  ].join('');
  const wa = waLink(ctx.whatsapp, messages.general());
  return `<header class="site-header">
  <div class="container header-inner">
    ${brand()}
    <nav class="main-nav" aria-label="Navegación principal"><ul class="nav-list">${links}</ul></nav>
    <a class="btn btn-primary btn-sm header-wa" href="${esc(wa)}" ${NEW_TAB} aria-label="Contactar por WhatsApp">${brandIcon('whatsapp')}<span class="header-wa-text">Contactar por WhatsApp</span></a>
    <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="mobile-menu" aria-label="Abrir menú">${icon('menu')}</button>
  </div>
  <div class="mobile-menu" id="mobile-menu" hidden>
    <nav class="container" aria-label="Navegación principal (móvil)">
      <ul class="mobile-list">${links}</ul>
      ${waButton({ number: ctx.whatsapp, message: messages.general(), label: 'Contactar por WhatsApp', cls: 'btn btn-primary btn-block' })}
    </nav>
  </div>
</header>`;
}

export function serviceCard(cat, number) {
  const n = cat.items.length;
  return `<article class="service-card reveal">
  <div class="icon-tile">${icon(cat.icon)}</div>
  <h3 class="service-title">${esc(cat.name)}</h3>
  <p class="service-desc">${esc(cat.description)}</p>
  <p class="service-count">${n} ${n === 1 ? 'opción' : 'opciones'} en catálogo</p>
  <div class="service-actions">
    <a class="link-arrow" href="#${anchorId(cat)}" data-jump="${esc(cat.slug)}">Ver catálogo ${icon('arrow-right')}</a>
    ${waButton({
      number,
      message: messages.category(cat.name),
      label: 'Consultar',
      cls: 'btn btn-soft btn-sm',
      ariaLabel: `Consultar por WhatsApp sobre ${cat.name}`,
    })}
  </div>
</article>`;
}

export function filters(categories) {
  const total = categories.reduce((sum, c) => sum + c.items.length, 0);
  const chip = (value, label, count, active = false) =>
    `<button type="button" class="chip${active ? ' is-active' : ''}" data-filter="${esc(value)}" aria-pressed="${active}">${esc(label)}<span class="chip-count">${count}</span></button>`;
  return [chip('all', 'Todas', total, true), ...categories.map((c) => chip(c.slug, c.shortName, c.items.length))].join('');
}

export function itemCard(item, cat, number) {
  const media = item.image
    ? `<img src="${esc(item.image)}" alt="${esc(item.name)}" loading="lazy" decoding="async" width="480" height="360">`
    : icon(cat.icon, 'icon placeholder-icon');
  return `<li class="item-card" data-search="${esc(normalize(`${item.name} ${item.description}`))}">
  <div class="item-media${item.image ? '' : ' is-placeholder'}">${media}</div>
  <div class="item-body">
    <span class="item-cat">${esc(cat.shortName)}</span>
    <h4 class="item-name">${esc(item.name)}</h4>
    ${item.description ? `<p class="item-desc">${esc(item.description)}</p>` : ''}
    ${waButton({
      number,
      message: messages.item(item.name, cat.name),
      label: 'Solicitar información',
      cls: 'btn btn-soft btn-sm item-cta',
      ariaLabel: `Solicitar información sobre ${item.name} por WhatsApp`,
    })}
  </div>
</li>`;
}

export function catalogGroup(cat, number) {
  const items = cat.items.length
    ? `<ul class="item-grid" role="list">${cat.items.map((i) => itemCard(i, cat, number)).join('')}</ul>`
    : `<div class="cat-empty">${icon('list')}<p>Estamos actualizando esta categoría. Escríbenos por WhatsApp para conocer las opciones disponibles.</p></div>`;
  return `<section class="cat-group" id="${anchorId(cat)}" data-cat="${esc(cat.slug)}" aria-labelledby="h-${anchorId(cat)}">
  <header class="cat-head">
    <div class="icon-tile icon-tile-lg">${icon(cat.icon)}</div>
    <div class="cat-head-text">
      <h3 id="h-${anchorId(cat)}">${esc(cat.name)}</h3>
      <p class="cat-desc">${esc(cat.description)}</p>
    </div>
    ${waButton({
      number,
      message: messages.category(cat.name),
      label: 'Solicitar información',
      cls: 'btn btn-outline btn-sm cat-cta',
      ariaLabel: `Solicitar información sobre ${cat.name} por WhatsApp`,
    })}
  </header>
  ${items}
</section>`;
}

export function socialLinks(social, cls = 'social') {
  const active = SOCIAL_NETWORKS.filter((n) => social[n.key]);
  if (!active.length) return '';
  return `<ul class="${cls}" role="list">${active
    .map(
      (n) =>
        `<li><a href="${esc(social[n.key])}" ${NEW_TAB} aria-label="${n.label} de Nexomed Biomédica (se abre en una pestaña nueva)">${brandIcon(n.key)}</a></li>`
    )
    .join('')}</ul>`;
}

export function footer(ctx, year) {
  const socials = socialLinks(ctx.social);
  return `<footer class="site-footer">
  <div class="container footer-grid">
    <div class="footer-brand">
      ${brand()}
      <p>Equipos médicos, estudios diagnósticos, consumibles, capacitación y mantenimiento de equipos médicos para el sector salud.</p>
    </div>
    <nav class="footer-col" aria-label="Categorías">
      <h2 class="footer-title">Catálogo</h2>
      <ul role="list">${ctx.categories.map((c) => `<li><a href="/#${anchorId(c)}">${esc(c.name)}</a></li>`).join('')}</ul>
    </nav>
    <div class="footer-col">
      <h2 class="footer-title">Contacto</h2>
      <p class="footer-note">Atendemos solicitudes de información por WhatsApp.</p>
      ${waButton({ number: ctx.whatsapp, message: messages.general(), label: 'Escribir por WhatsApp', cls: 'btn btn-primary btn-sm' })}
      ${socials ? `<h2 class="footer-title footer-title-gap">Síguenos</h2>${socials}` : ''}
    </div>
  </div>
  <div class="container footer-bottom">
    <p>© ${year} Nexomed Biomédica. Todos los derechos reservados.</p>
    <a href="/aviso-de-privacidad">Aviso de privacidad</a>
  </div>
</footer>`;
}

export function waFloat(number) {
  return `<a class="wa-float" href="${esc(waLink(number, messages.general()))}" ${NEW_TAB} aria-label="Escríbenos por WhatsApp">${brandIcon('whatsapp')}</a>`;
}
