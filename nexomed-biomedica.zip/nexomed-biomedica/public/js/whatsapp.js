// Enlaces y mensajes prellenados de WhatsApp (único canal de contacto).

export const COMPANY = 'Nexomed Biomédica';

export function waLink(number, message) {
  const base = `https://wa.me/${number}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export const messages = {
  general: () =>
    `Hola, ${COMPANY}. Me gustaría solicitar información sobre sus productos y servicios.`,
  category: (categoryName) =>
    `Hola, ${COMPANY}. Me interesa obtener información sobre la categoría «${categoryName}». ¿Podrían proporcionarme más detalles?`,
  item: (itemName, categoryName) =>
    `Hola, ${COMPANY}. Me interesa obtener información sobre «${itemName}» (categoría: ${categoryName}). ¿Podrían proporcionarme más detalles?`,
  search: (query) =>
    `Hola, ${COMPANY}. Busqué «${query}» en su sitio web y no lo encontré en el catálogo. ¿Podrían orientarme?`,
};
