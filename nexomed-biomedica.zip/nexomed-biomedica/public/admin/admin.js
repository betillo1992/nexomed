// Panel de administración de Nexomed Biomédica.
// Toda la seguridad se aplica en el servidor; este archivo solo es la interfaz.
import { icon, brandIcon, CATEGORY_ICONS } from '/js/icons.js';
import { esc, normalize, SOCIAL_NETWORKS } from '/js/templates.js';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

let data = null;
let busy = false;

for (const el of $$('[data-icon]')) el.insertAdjacentHTML('afterbegin', icon(el.dataset.icon));

/* ---------- API ---------- */

class ApiError extends Error {
  constructor(message, status, field) {
    super(message);
    this.status = status;
    this.field = field;
  }
}

async function api(url, { method = 'GET', body, raw } = {}) {
  const opts = { method, headers: { 'X-Nexomed-Admin': '1' }, credentials: 'same-origin' };
  if (raw) {
    opts.headers['Content-Type'] = raw.type || 'application/octet-stream';
    opts.body = raw;
  } else if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(url, opts);
  } catch {
    throw new ApiError('No se pudo conectar con el servidor. Revisa tu conexión.', 0);
  }
  let payload = null;
  try {
    payload = await res.json();
  } catch {
    // Respuesta sin cuerpo JSON.
  }
  if (res.status === 401 && !url.endsWith('/login')) {
    showLogin({ error: 'Tu sesión expiró. Inicia sesión de nuevo.' });
  }
  if (!res.ok) throw new ApiError(payload?.error || 'Ocurrió un error inesperado.', res.status, payload?.field);
  return payload;
}

function setData(catalog) {
  data = catalog;
  renderAll();
}

/* ---------- Avisos ---------- */

function toast(message, type = 'ok') {
  const el = document.createElement('div');
  el.className = `toast ${type === 'error' ? 'error' : ''}`;
  el.innerHTML = `${icon(type === 'error' ? 'alert' : 'check')}<span>${esc(message)}</span>`;
  const box = $('#toasts');
  box.append(el);
  while (box.children.length > 3) box.firstElementChild.remove();
  setTimeout(() => el.remove(), type === 'error' ? 6000 : 3200);
}

async function run(task, success) {
  if (busy) return;
  busy = true;
  try {
    await task();
    if (success) toast(success);
  } catch (err) {
    if (err.status !== 401) toast(err.message, 'error');
  } finally {
    busy = false;
  }
}

/* ---------- Sesión ---------- */

function showLogin({ setup = false, error = '' } = {}) {
  for (const d of $$('dialog[open]')) d.close();
  $('#boot').hidden = true;
  $('#panel-view').hidden = true;
  $('#login-view').hidden = false;
  const setupBox = $('#login-setup');
  setupBox.hidden = !setup;
  setupBox.innerHTML = setup
    ? `${icon('alert')}<span>Aún no existe una cuenta de administración. En la carpeta del proyecto, en el servidor, ejecuta <code>npm run admin:crear</code> y vuelve a cargar esta página.</span>`
    : '';
  $('#login-form').hidden = setup;
  const box = $('#login-error');
  box.hidden = !error;
  box.textContent = error;
  if (!setup) $('#login-user').focus();
}

async function enterPanel(username) {
  const res = await api('/api/admin/catalog');
  $('#adm-user').textContent = username;
  $('#login-view').hidden = true;
  $('#boot').hidden = true;
  $('#panel-view').hidden = false;
  setData(res.catalog);
}

$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = $('#login-user').value.trim();
  const password = $('#login-pass').value;
  const box = $('#login-error');
  if (!username || !password) {
    box.textContent = 'Escribe tu usuario y contraseña.';
    box.hidden = false;
    return;
  }
  const btn = $('#login-submit');
  btn.disabled = true;
  btn.textContent = 'Verificando…';
  try {
    const res = await api('/api/auth/login', { method: 'POST', body: { username, password } });
    $('#login-pass').value = '';
    box.hidden = true;
    await enterPanel(res.username);
  } catch (err) {
    box.textContent = err.message;
    box.hidden = false;
    $('#login-pass').select();
  } finally {
    btn.disabled = false;
    btn.textContent = 'Iniciar sesión';
  }
});

$('#logout').addEventListener('click', async () => {
  try {
    await api('/api/auth/logout', { method: 'POST' });
  } catch {
    // La sesión se cierra localmente de todas formas.
  }
  data = null;
  showLogin();
});

/* ---------- Pestañas ---------- */

const tabs = $$('.adm-tab');
function selectTab(name, focus = false) {
  for (const tab of tabs) {
    const active = tab.dataset.tab === name;
    tab.setAttribute('aria-selected', String(active));
    tab.tabIndex = active ? 0 : -1;
    $(`#${tab.getAttribute('aria-controls')}`).hidden = !active;
    if (active && focus) tab.focus();
  }
}
for (const tab of tabs) {
  tab.addEventListener('click', () => selectTab(tab.dataset.tab));
  tab.addEventListener('keydown', (e) => {
    const i = tabs.indexOf(tab);
    if (e.key === 'ArrowRight') selectTab(tabs[(i + 1) % tabs.length].dataset.tab, true);
    if (e.key === 'ArrowLeft') selectTab(tabs[(i - 1 + tabs.length) % tabs.length].dataset.tab, true);
  });
}

/* ---------- Render ---------- */

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const findCategory = (id) => data.categories.find((c) => c.id === id);
function findItem(id) {
  for (const cat of data.categories) {
    const item = cat.items.find((i) => i.id === id);
    if (item) return { item, cat };
  }
  return {};
}

function renderAll() {
  renderFilterOptions();
  renderCatalog();
  renderCategories();
  renderSocial();
  renderBackup();
}

function renderFilterOptions() {
  const select = $('#adm-filter');
  const current = select.value;
  select.innerHTML =
    `<option value="all">Todas las categorías</option>` +
    data.categories.map((c) => `<option value="${esc(c.id)}">${esc(c.name)} (${c.items.length})</option>`).join('');
  select.value = data.categories.some((c) => c.id === current) ? current : 'all';
}

function itemRow(item, cat, index, total, searching) {
  const thumb = item.image ? `<img src="${esc(item.image)}" alt="">` : icon(cat.icon);
  const name = esc(item.name);
  return `<li class="adm-row${item.published ? '' : ' is-hidden'}" data-id="${esc(item.id)}">
    <span class="adm-thumb">${thumb}</span>
    <div class="adm-row-main">
      <div class="adm-row-name">${name}${item.published ? '' : '<span class="tag tag-hidden">Oculto</span>'}</div>
      <div class="adm-row-desc">${item.description ? esc(item.description) : '<em>Sin descripción</em>'}</div>
    </div>
    <div class="adm-row-actions">
      <button class="toggle" type="button" role="switch" aria-checked="${item.published}" data-action="toggle" data-id="${esc(item.id)}" aria-label="Publicado: ${name}">${item.published ? 'Publicado' : 'Oculto'}</button>
      <button class="icon-btn" type="button" data-action="up" data-id="${esc(item.id)}" aria-label="Subir ${name}" title="Subir" ${searching || index === 0 ? 'disabled' : ''}>${icon('chevron-up')}</button>
      <button class="icon-btn" type="button" data-action="down" data-id="${esc(item.id)}" aria-label="Bajar ${name}" title="Bajar" ${searching || index === total - 1 ? 'disabled' : ''}>${icon('chevron-down')}</button>
      <button class="icon-btn" type="button" data-action="edit" data-id="${esc(item.id)}" aria-label="Editar ${name}" title="Editar">${icon('pencil')}</button>
      <button class="icon-btn danger" type="button" data-action="delete" data-id="${esc(item.id)}" aria-label="Eliminar ${name}" title="Eliminar">${icon('trash')}</button>
    </div>
  </li>`;
}

function renderCatalog() {
  const q = normalize($('#adm-search').value);
  const filter = $('#adm-filter').value;
  const cats = data.categories.filter((c) => filter === 'all' || c.id === filter);
  const html = cats
    .map((cat) => {
      const items = cat.items.filter((i) => !q || normalize(i.name).includes(q));
      if (q && !items.length) return '';
      const published = cat.items.filter((i) => i.published).length;
      const manual = cat.sortMode === 'manual';
      return `<section class="adm-card" aria-label="${esc(cat.name)}">
        <header class="adm-cat-head">
          <div class="adm-cat-title">
            <span class="icon-tile">${icon(cat.icon)}</span>
            <div>
              <h2>${esc(cat.name)}</h2>
              <div class="adm-meta">
                <span>${plural(cat.items.length, 'elemento', 'elementos')} · ${published} publicados</span>
                <span class="tag ${manual ? 'tag-manual' : 'tag-alpha'}">${manual ? 'Orden manual' : 'Orden alfabético'}</span>
              </div>
            </div>
          </div>
          <div class="adm-cat-actions">
            <button class="btn btn-outline btn-sm" type="button" data-action="sort-alpha" data-cat="${esc(cat.id)}" ${manual ? '' : 'disabled title="La categoría ya está en orden alfabético"'}>${icon('sort-az')}Ordenar A-Z</button>
            <button class="btn btn-soft btn-sm" type="button" data-action="new-item" data-cat="${esc(cat.id)}">${icon('plus')}Agregar</button>
          </div>
        </header>
        ${
          items.length
            ? `<ul class="adm-rows" role="list">${items.map((it, i) => itemRow(it, cat, i, items.length, Boolean(q))).join('')}</ul>`
            : `<p class="adm-empty">Esta categoría todavía no tiene elementos.</p>`
        }
      </section>`;
    })
    .join('');
  $('#catalog-list').innerHTML =
    html || `<div class="adm-empty-page">No hay elementos que coincidan con «${esc($('#adm-search').value.trim())}».</div>`;
}

function renderCategories() {
  const total = data.categories.length;
  $('#category-list').innerHTML = data.categories
    .map((cat, i) => {
      const name = esc(cat.name);
      return `<li class="adm-row" data-id="${esc(cat.id)}">
        <span class="icon-tile">${icon(cat.icon)}</span>
        <div class="adm-row-main">
          <div class="adm-row-name">${name}<span class="tag">Menú: ${esc(cat.shortName)}</span><span class="tag">${plural(cat.items.length, 'elemento', 'elementos')}</span></div>
          <div class="adm-row-desc">${cat.description ? esc(cat.description) : '<em>Sin descripción</em>'}</div>
        </div>
        <div class="adm-row-actions">
          <button class="icon-btn" type="button" data-action="cat-up" data-id="${esc(cat.id)}" aria-label="Subir ${name}" title="Subir" ${i === 0 ? 'disabled' : ''}>${icon('chevron-up')}</button>
          <button class="icon-btn" type="button" data-action="cat-down" data-id="${esc(cat.id)}" aria-label="Bajar ${name}" title="Bajar" ${i === total - 1 ? 'disabled' : ''}>${icon('chevron-down')}</button>
          <button class="icon-btn" type="button" data-action="cat-edit" data-id="${esc(cat.id)}" aria-label="Editar ${name}" title="Editar">${icon('pencil')}</button>
          <button class="icon-btn danger" type="button" data-action="cat-delete" data-id="${esc(cat.id)}" aria-label="Eliminar ${name}" title="${total <= 1 ? 'Debe existir al menos una categoría' : 'Eliminar'}" ${total <= 1 ? 'disabled' : ''}>${icon('trash')}</button>
        </div>
      </li>`;
    })
    .join('');
}

const SOCIAL_DOMAINS = { facebook: 'facebook.com', instagram: 'instagram.com', tiktok: 'tiktok.com' };

function renderSocial() {
  const social = data.settings.social || {};
  $('#social-form').innerHTML = `${SOCIAL_NETWORKS.map(({ key, label }) => {
    const value = social[key] || '';
    return `<div class="social-row">
      <span class="social-icon">${brandIcon(key)}</span>
      <div class="field">
        <div class="field-row">
          <label class="label" for="social-${key}">${label}</label>
          <span class="social-state ${value ? 'on' : 'off'}">${value ? 'Visible en el sitio' : 'Sin configurar · no se muestra'}</span>
        </div>
        <input class="input" type="url" id="social-${key}" name="${key}" value="${esc(value)}" placeholder="https://www.${SOCIAL_DOMAINS[key]}/…" inputmode="url" autocomplete="off" spellcheck="false" aria-describedby="social-${key}-error">
        <p class="field-error" id="social-${key}-error" hidden></p>
      </div>
    </div>`;
  }).join('')}
  <div class="form-actions"><button class="btn btn-dark" type="submit">${icon('check')}Guardar redes sociales</button></div>`;
}

function renderBackup() {
  const updated = data.updatedAt
    ? new Date(data.updatedAt).toLocaleString('es-MX', { dateStyle: 'long', timeStyle: 'short' })
    : '—';
  $('#backup-card').innerHTML = `<ul class="info-list" role="list">
      <li>${icon('check')}<span>Los cambios se guardan en el servidor y se publican de inmediato para todos los visitantes y dispositivos.</span></li>
      <li>${icon('check')}<span>Antes de cada cambio se crea una copia automática en <code>data/backups</code> (se conservan las 30 más recientes).</span></li>
      <li>${icon('check')}<span>Última modificación: <b>${esc(updated)}</b>.</span></li>
    </ul>
    <a class="btn btn-dark" href="/api/admin/export" download>${icon('download')}Descargar respaldo (JSON)</a>
    <p class="help backup-note"></p>`;
  $('#backup-card .help').textContent =
    'Para restaurar un respaldo, reemplaza data/catalog.json en el servidor por el archivo descargado y reinicia el servidor.';
}

/* ---------- Catálogo: acciones ---------- */

$('#adm-search').addEventListener('input', renderCatalog);
$('#adm-filter').addEventListener('change', renderCatalog);

function refocus(selector) {
  const el = $(selector);
  if (!el || el.disabled) return false;
  el.focus();
  return true;
}

async function moveItem(id, direction) {
  const { cat } = findItem(id);
  const ids = cat.items.map((i) => i.id);
  const from = ids.indexOf(id);
  const to = from + (direction === 'up' ? -1 : 1);
  if (to < 0 || to >= ids.length) return;
  [ids[from], ids[to]] = [ids[to], ids[from]];
  const wasAlpha = cat.sortMode !== 'manual';
  await run(async () => {
    const res = await api(`/api/admin/categories/${cat.id}/order`, { method: 'POST', body: { itemIds: ids } });
    setData(res.catalog);
    refocus(`[data-action="${direction}"][data-id="${id}"]`) ||
      refocus(`[data-action="${direction === 'up' ? 'down' : 'up'}"][data-id="${id}"]`);
  }, wasAlpha ? 'Orden actualizado. La categoría ahora usa orden manual.' : 'Orden actualizado.');
}

$('#catalog-list').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-action]');
  if (!btn || btn.disabled) return;
  const { action, id } = btn.dataset;

  if (action === 'new-item') return openItemDialog(null, btn.dataset.cat);
  if (action === 'up' || action === 'down') return moveItem(id, action);

  if (action === 'sort-alpha') {
    const cat = findCategory(btn.dataset.cat);
    const choice = await confirmDialog({
      title: `¿Ordenar «${cat.name}» alfabéticamente?`,
      text: 'Se reemplazará el orden manual actual. Los nuevos elementos se acomodarán automáticamente por nombre.',
      okLabel: 'Ordenar A-Z',
      tone: 'info',
    });
    if (choice !== 'ok') return;
    return run(async () => {
      setData((await api(`/api/admin/categories/${cat.id}/sort-alpha`, { method: 'POST' })).catalog);
    }, 'Categoría ordenada alfabéticamente.');
  }

  const { item } = findItem(id);
  if (!item) return;

  if (action === 'edit') return openItemDialog(item);

  if (action === 'toggle') {
    return run(async () => {
      const res = await api(`/api/admin/items/${id}/published`, { method: 'PATCH', body: { published: !item.published } });
      setData(res.catalog);
      refocus(`[data-action="toggle"][data-id="${id}"]`);
    }, item.published ? `«${item.name}» ya no se muestra en el sitio.` : `«${item.name}» está publicado.`);
  }

  if (action === 'delete') {
    const choice = await confirmDialog({
      title: `¿Eliminar «${item.name}»?`,
      text: 'Esta acción no se puede deshacer. Si solo quieres dejar de mostrarlo, puedes ocultarlo y conservar su información.',
      okLabel: 'Eliminar',
      altLabel: item.published ? 'Ocultar en su lugar' : '',
    });
    if (choice === 'ok') {
      return run(async () => {
        setData((await api(`/api/admin/items/${id}`, { method: 'DELETE' })).catalog);
      }, 'Elemento eliminado.');
    }
    if (choice === 'alt') {
      return run(async () => {
        setData((await api(`/api/admin/items/${id}/published`, { method: 'PATCH', body: { published: false } })).catalog);
      }, `«${item.name}» quedó oculto.`);
    }
  }
});

$('#new-item-main').addEventListener('click', () => {
  const filter = $('#adm-filter').value;
  openItemDialog(null, filter !== 'all' ? filter : data.categories[0]?.id);
});

/* ---------- Diálogos: utilidades ---------- */

for (const btn of $$('[data-close]')) btn.addEventListener('click', () => btn.closest('dialog').close());

// Al corregir un campo se retira su mensaje de error.
document.addEventListener('input', (e) => {
  const field = e.target.closest('.field');
  if (!field || e.target.getAttribute('aria-invalid') !== 'true') return;
  e.target.removeAttribute('aria-invalid');
  const error = $('.field-error', field);
  if (error) error.hidden = true;
});

function clearErrors(form) {
  for (const el of $$('.field-error', form)) {
    el.hidden = true;
    el.textContent = '';
  }
  for (const el of $$('[aria-invalid]', form)) el.removeAttribute('aria-invalid');
  for (const el of $$('.alert-error', form)) el.hidden = true;
}

function fieldError(prefix, field, message) {
  const box = $(`#${prefix}-${field}-error`);
  if (!box) return false;
  box.textContent = message;
  box.hidden = false;
  const input = $(`#${prefix}-${field}`) || $(`[name="${field}"]`, box.closest('form'));
  input?.setAttribute('aria-invalid', 'true');
  return input;
}

function showErrors(prefix, errors) {
  let first = null;
  for (const [field, message] of Object.entries(errors)) {
    const input = fieldError(prefix, field, message);
    if (!first && input) first = input;
  }
  first?.focus();
  return Boolean(Object.keys(errors).length);
}

function confirmDialog({ title, text, okLabel = 'Aceptar', altLabel = '', tone = 'danger' }) {
  const dialog = $('#confirm-dialog');
  $('#confirm-title').textContent = title;
  $('#confirm-text').textContent = text;
  $('#confirm-icon').innerHTML = icon(tone === 'danger' ? 'trash' : 'sort-az');
  const ok = $('#confirm-ok');
  ok.textContent = okLabel;
  ok.className = `btn ${tone === 'danger' ? 'btn-danger' : 'btn-dark'}`;
  const alt = $('#confirm-alt');
  alt.hidden = !altLabel;
  alt.textContent = altLabel;
  return new Promise((resolve) => {
    let result = 'cancel';
    const buttons = [ok, alt, $('#confirm-cancel')];
    const onClick = (e) => {
      result = e.currentTarget.value;
      dialog.close();
    };
    buttons.forEach((b) => b.addEventListener('click', onClick));
    dialog.addEventListener(
      'close',
      () => {
        buttons.forEach((b) => b.removeEventListener('click', onClick));
        resolve(result);
      },
      { once: true }
    );
    dialog.showModal();
    $('#confirm-cancel').focus();
  });
}

/* ---------- Formulario de elemento ---------- */

const itemDialog = $('#item-dialog');
const itemForm = $('#item-form');
let editingItem = null;
const image = { url: null, blob: null, preview: null };

function setPreview(src) {
  if (image.preview) URL.revokeObjectURL(image.preview);
  image.preview = src?.startsWith('blob:') ? src : null;
  $('#item-image-preview').innerHTML = src ? `<img src="${esc(src)}" alt="Vista previa de la imagen">` : icon('image');
  $('#item-image-remove').hidden = !src;
  $('#item-image-btn-label').textContent = src ? 'Cambiar imagen' : 'Elegir imagen';
}

function updateCounters() {
  $('#item-name-count').textContent = `${$('#item-name').value.length}/120`;
  $('#item-description-count').textContent = `${$('#item-description').value.length}/600`;
}

function openItemDialog(item = null, categoryId = null) {
  editingItem = item;
  clearErrors(itemForm);
  $('#item-dialog-title').textContent = item ? 'Editar elemento' : 'Nuevo elemento';
  $('#item-submit').textContent = item ? 'Guardar cambios' : 'Agregar elemento';
  $('#item-category').innerHTML = data.categories.map((c) => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');
  $('#item-name').value = item?.name || '';
  $('#item-description').value = item?.description || '';
  $('#item-category').value = item?.categoryId || categoryId || data.categories[0]?.id || '';
  $('#item-published').checked = item ? item.published : true;
  $('#item-image').value = '';
  image.url = item?.image || null;
  image.blob = null;
  setPreview(image.url);
  updateCounters();
  itemDialog.showModal();
  $('#item-name').focus();
}

itemDialog.addEventListener('close', () => setPreview(null));
$('#item-name').addEventListener('input', updateCounters);
$('#item-description').addEventListener('input', updateCounters);

// Reduce las fotos grandes (p. ej. de celular) antes de subirlas.
async function prepareImage(file) {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type)) throw new Error('Formato no admitido. Usa una imagen JPG, PNG o WebP.');
  if (file.size > 20 * 1024 * 1024) throw new Error('La imagen es demasiado grande (máximo 20 MB).');
  const bitmap = await createImageBitmap(file);
  const max = 1400;
  const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
  if (scale === 1 && file.size <= 1.5 * 1024 * 1024) return file;
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  let blob = await new Promise((r) => canvas.toBlob(r, 'image/webp', 0.86));
  if (!blob || blob.type !== 'image/webp') {
    ctx.globalCompositeOperation = 'destination-over';
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    blob = await new Promise((r) => canvas.toBlob(r, 'image/jpeg', 0.86));
  }
  if (blob.size > 3 * 1024 * 1024) throw new Error('No se pudo reducir la imagen a menos de 3 MB. Prueba con otra.');
  return blob;
}

$('#item-image').addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  const box = $('#item-image-error');
  box.hidden = true;
  if (!file) return;
  try {
    image.blob = await prepareImage(file);
    setPreview(URL.createObjectURL(image.blob));
  } catch (err) {
    box.textContent = err.message;
    box.hidden = false;
    e.target.value = '';
  }
});

$('#item-image-remove').addEventListener('click', () => {
  image.url = null;
  image.blob = null;
  $('#item-image').value = '';
  setPreview(null);
});

itemForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(itemForm);
  const payload = {
    name: $('#item-name').value.trim().replace(/\s+/g, ' '),
    categoryId: $('#item-category').value,
    description: $('#item-description').value.trim(),
    published: $('#item-published').checked,
  };
  const errors = {};
  if (payload.name.length < 2) errors.name = 'Escribe un nombre de al menos 2 caracteres.';
  else if (payload.name.length > 120) errors.name = 'El nombre admite como máximo 120 caracteres.';
  if (!findCategory(payload.categoryId)) errors.categoryId = 'Selecciona una categoría.';
  if (payload.description.length > 600) errors.description = 'La descripción admite como máximo 600 caracteres.';
  if (showErrors('item', errors)) return;

  const submit = $('#item-submit');
  const label = submit.textContent;
  submit.disabled = true;
  submit.textContent = 'Guardando…';
  try {
    if (image.blob) {
      const uploaded = await api('/api/admin/uploads', { method: 'POST', raw: image.blob });
      image.url = uploaded.url;
      image.blob = null;
    }
    payload.image = image.url;
    const res = editingItem
      ? await api(`/api/admin/items/${editingItem.id}`, { method: 'PUT', body: payload })
      : await api('/api/admin/items', { method: 'POST', body: payload });
    itemDialog.close();
    setData(res.catalog);
    toast(editingItem ? 'Cambios guardados.' : `«${payload.name}» se agregó al catálogo.`);
  } catch (err) {
    if (err.status === 401) return;
    if (!err.field || !fieldError('item', err.field, err.message)) {
      const box = $('#item-form-error');
      box.textContent = err.message;
      box.hidden = false;
    } else {
      $(`#item-${err.field}`)?.focus();
    }
  } finally {
    submit.disabled = false;
    submit.textContent = label;
  }
});

/* ---------- Categorías ---------- */

const categoryDialog = $('#category-dialog');
const categoryForm = $('#category-form');
let editingCategory = null;

function openCategoryDialog(cat = null) {
  editingCategory = cat;
  clearErrors(categoryForm);
  $('#category-dialog-title').textContent = cat ? 'Editar categoría' : 'Nueva categoría';
  $('#category-submit').textContent = cat ? 'Guardar cambios' : 'Crear categoría';
  $('#category-name').value = cat?.name || '';
  $('#category-shortName').value = cat && cat.shortName !== cat.name ? cat.shortName : '';
  $('#category-description').value = cat?.description || '';
  const selected = cat?.icon || 'stethoscope';
  $('#category-icons').innerHTML = CATEGORY_ICONS.map(
    (opt) => `<label class="icon-option" title="${esc(opt.label)}">
      <input type="radio" name="icon" value="${opt.key}" ${opt.key === selected ? 'checked' : ''} aria-label="${esc(opt.label)}">
      <span>${icon(opt.key)}</span>
    </label>`
  ).join('');
  categoryDialog.showModal();
  $('#category-name').focus();
}

$('#new-category-main').addEventListener('click', () => openCategoryDialog());

categoryForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(categoryForm);
  const payload = {
    name: $('#category-name').value.trim().replace(/\s+/g, ' '),
    shortName: $('#category-shortName').value.trim().replace(/\s+/g, ' '),
    description: $('#category-description').value.trim(),
    icon: $('input[name="icon"]:checked', categoryForm)?.value || 'stethoscope',
  };
  const errors = {};
  if (payload.name.length < 2) errors.name = 'Escribe un nombre de al menos 2 caracteres.';
  else if (payload.name.length > 80) errors.name = 'El nombre admite como máximo 80 caracteres.';
  if (payload.shortName.length > 30) errors.shortName = 'El nombre corto admite como máximo 30 caracteres.';
  if (payload.description.length > 400) errors.description = 'La descripción admite como máximo 400 caracteres.';
  if (showErrors('category', errors)) return;

  const submit = $('#category-submit');
  submit.disabled = true;
  try {
    const res = editingCategory
      ? await api(`/api/admin/categories/${editingCategory.id}`, { method: 'PUT', body: payload })
      : await api('/api/admin/categories', { method: 'POST', body: payload });
    categoryDialog.close();
    setData(res.catalog);
    toast(editingCategory ? 'Categoría actualizada.' : `Categoría «${payload.name}» creada.`);
  } catch (err) {
    if (err.status === 401) return;
    if (!err.field || !fieldError('category', err.field, err.message)) {
      const box = $('#category-form-error');
      box.textContent = err.message;
      box.hidden = false;
    }
  } finally {
    submit.disabled = false;
  }
});

async function moveCategory(id, direction) {
  const ids = data.categories.map((c) => c.id);
  const from = ids.indexOf(id);
  const to = from + (direction === 'up' ? -1 : 1);
  if (to < 0 || to >= ids.length) return;
  [ids[from], ids[to]] = [ids[to], ids[from]];
  await run(async () => {
    setData((await api('/api/admin/categories/order', { method: 'POST', body: { categoryIds: ids } })).catalog);
    refocus(`[data-action="cat-${direction}"][data-id="${id}"]`);
  }, 'Orden de categorías actualizado.');
}

$('#category-list').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-action]');
  if (!btn || btn.disabled) return;
  const cat = findCategory(btn.dataset.id);
  if (!cat) return;
  const { action } = btn.dataset;
  if (action === 'cat-up') moveCategory(cat.id, 'up');
  if (action === 'cat-down') moveCategory(cat.id, 'down');
  if (action === 'cat-edit') openCategoryDialog(cat);
  if (action === 'cat-delete') openDeleteCategory(cat);
});

/* ---------- Eliminar categoría (con protección contra pérdidas) ---------- */

const delDialog = $('#delete-category-dialog');
let deletingCategory = null;

function openDeleteCategory(cat) {
  deletingCategory = cat;
  const others = data.categories.filter((c) => c.id !== cat.id);
  const n = cat.items.length;
  $('#delcat-body').innerHTML = `
    <p>Vas a eliminar la categoría <b>«${esc(cat.name)}»</b>.</p>
    ${
      n
        ? `<p class="help delcat-intro"></p>
      <label class="radio-card"><input type="radio" name="itemsAction" value="move" checked>
        <span><b>Mover los elementos a otra categoría</b>
          <select class="select" id="delcat-target" aria-label="Categoría de destino">${others
            .map((c) => `<option value="${esc(c.id)}">${esc(c.name)}</option>`)
            .join('')}</select>
        </span></label>
      <label class="radio-card"><input type="radio" name="itemsAction" value="delete">
        <span><b>Eliminar también ${n === 1 ? 'el elemento' : `los ${n} elementos`}</b><span class="help">Se borrarán definitivamente junto con sus imágenes.</span></span></label>`
        : '<p class="help delcat-intro">Esta categoría no contiene elementos.</p>'
    }
    <div class="field delcat-confirm">
      <label class="label" for="delcat-name"></label>
      <input class="input" id="delcat-name" autocomplete="off" spellcheck="false">
    </div>
    <div class="alert alert-error" id="delcat-error" role="alert" hidden></div>`;
  if (n) $('#delcat-body .delcat-intro').textContent = `Contiene ${plural(n, 'elemento', 'elementos')}. Elige qué hacer con ${n === 1 ? 'él' : 'ellos'}:`;
  $('label[for="delcat-name"]').textContent = `Para confirmar, escribe el nombre de la categoría: ${cat.name}`;
  $('#delcat-submit').disabled = true;
  delDialog.showModal();
  $('#delcat-name').focus();
}

$('#delcat-body').addEventListener('input', (e) => {
  if (e.target.id === 'delcat-name') {
    $('#delcat-submit').disabled = normalize(e.target.value) !== normalize(deletingCategory.name);
  }
});
$('#delcat-body').addEventListener('change', (e) => {
  if (e.target.name === 'itemsAction') $('#delcat-target').disabled = e.target.value !== 'move';
});

$('#delcat-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const cat = deletingCategory;
  const body = { confirmName: $('#delcat-name').value };
  if (cat.items.length) {
    body.itemsAction = $('input[name="itemsAction"]:checked', delDialog).value;
    body.targetCategoryId = $('#delcat-target').value;
  }
  const submit = $('#delcat-submit');
  submit.disabled = true;
  try {
    const res = await api(`/api/admin/categories/${cat.id}`, { method: 'DELETE', body });
    delDialog.close();
    setData(res.catalog);
    toast(`Categoría «${cat.name}» eliminada.`);
  } catch (err) {
    if (err.status === 401) return;
    const box = $('#delcat-error');
    box.textContent = err.message;
    box.hidden = false;
    submit.disabled = false;
  }
});

/* ---------- Redes sociales ---------- */

$('#social-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.currentTarget;
  clearErrors(form);
  const social = {};
  const errors = {};
  for (const { key, label } of SOCIAL_NETWORKS) {
    const value = $(`#social-${key}`).value.trim();
    social[key] = value;
    if (value && !/^https:\/\//i.test(value)) errors[key] = `La dirección de ${label} debe comenzar con https://`;
  }
  if (showErrors('social', errors)) return;
  const submit = $('button[type="submit"]', form);
  submit.disabled = true;
  try {
    setData((await api('/api/admin/settings', { method: 'PUT', body: { social } })).catalog);
    toast('Redes sociales guardadas.');
  } catch (err) {
    if (err.status === 401) return;
    if (!err.field || !fieldError('social', err.field, err.message)) toast(err.message, 'error');
    else $(`#social-${err.field}`)?.focus();
  } finally {
    $('button[type="submit"]', $('#social-form')).disabled = false;
  }
});

/* ---------- Inicio ---------- */

(async function boot() {
  try {
    const me = await api('/api/auth/me');
    if (me.authenticated) await enterPanel(me.username);
    else showLogin({ setup: !me.configured });
  } catch (err) {
    showLogin({ error: err.message });
  }
})();
