// Catálogo inicial. Solo se usa la primera vez que arranca el servidor (cuando
// aún no existe data/catalog.json); después todo se edita desde /admin.
import crypto from 'node:crypto';
import { collator } from './catalog.js';

const CATEGORIES = [
  {
    slug: 'equipos-medicos',
    name: 'Equipos médicos',
    shortName: 'Equipos médicos',
    icon: 'monitor',
    description:
      'Equipos para el monitoreo, la valoración y el apoyo terapéutico en consultorios, clínicas, hospitales y atención domiciliaria.',
    items: ['Baumanómetro', 'CPAP', 'Concentradores de oxígeno', 'Electrocardiógrafo', 'Monitor de signos vitales', 'Oxímetro', 'Termómetro'],
  },
  {
    slug: 'estudios-diagnosticos',
    name: 'Estudios diagnósticos',
    shortName: 'Estudios',
    icon: 'clipboard-pulse',
    description: 'Estudios diagnósticos que apoyan la valoración clínica indicada por el médico tratante.',
    items: [
      'Electrocardiograma',
      'Electroencefalograma',
      'Espirometría',
      'Holter',
      'Monitoreo Ambulatorio de la Presión Arterial (MAPA)',
    ],
  },
  {
    slug: 'consumibles',
    name: 'Consumibles',
    shortName: 'Consumibles',
    icon: 'package',
    description: 'Insumos de uso frecuente para la operación diaria de equipos médicos.',
    items: ['Cal sodada', 'Gel conductor', 'Papel para electrocardiograma'],
  },
  {
    slug: 'capacitacion',
    name: 'Capacitación',
    shortName: 'Capacitación',
    icon: 'graduation',
    description:
      'Capacitación especializada para personal del sector salud sobre el uso adecuado y el cuidado de equipos médicos.',
    items: [
      'Autoclaves',
      'Bombas de infusión',
      'Desfibriladores',
      'Electrocauterios',
      'Electrocardiogramas',
      'Máquinas de anestesia',
      'Monitores de signos vitales',
    ],
  },
  {
    slug: 'mantenimiento',
    name: 'Mantenimiento de equipos médicos',
    shortName: 'Mantenimiento',
    icon: 'wrench',
    description:
      'Servicios de mantenimiento preventivo y correctivo para equipos médicos, realizados por personal biomédico. Incluimos la identificación y el etiquetado de los equipos intervenidos por nuestro personal, de acuerdo con el servicio realizado.',
    items: [
      'Autoclaves',
      'Camas hospitalarias',
      'Concentradores de oxígeno',
      'Lámparas de quirófano',
      'Monitores de signos vitales',
    ],
  },
];

export function buildSeed() {
  const now = new Date().toISOString();
  const categories = [];
  const items = [];
  CATEGORIES.forEach((def, index) => {
    const id = crypto.randomUUID();
    categories.push({
      id,
      slug: def.slug,
      name: def.name,
      shortName: def.shortName,
      description: def.description,
      icon: def.icon,
      sortMode: 'alpha',
      order: index,
    });
    [...def.items].sort(collator.compare).forEach((name, order) => {
      items.push({
        id: crypto.randomUUID(),
        categoryId: id,
        name,
        description: '',
        image: null,
        published: true,
        order,
        createdAt: now,
        updatedAt: now,
      });
    });
  });
  return {
    version: 1,
    updatedAt: now,
    settings: { social: { facebook: '', instagram: '', tiktok: '' } },
    categories,
    items,
  };
}
