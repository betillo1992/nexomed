// Renderizado de las páginas públicas a partir de las vistas en /views.
import fs from 'node:fs';
import path from 'node:path';
import { IS_PROD, SITE_URL, VIEWS_DIR, WHATSAPP_DISPLAY } from './config.js';
import { getState } from './store.js';
import { publicView } from './catalog.js';
import * as T from '../public/js/templates.js';
import { waLink, messages } from '../public/js/whatsapp.js';
import { brandIcon } from '../public/js/icons.js';

const cache = new Map();
function view(name) {
  if (IS_PROD && cache.has(name)) return cache.get(name);
  const html = fs.readFileSync(path.join(VIEWS_DIR, name), 'utf8');
  cache.set(name, html);
  return html;
}

const fill = (html, values) =>
  html.replace(/<!--@(\w+)-->|\{\{(\w+)\}\}/g, (match, a, b) => {
    const key = a || b;
    return key in values ? values[key] : match;
  });

const jsonForHtml = (data) => JSON.stringify(data).replace(/</g, '\\u003c');

function seo(ctx, pathname) {
  const tags = [];
  if (SITE_URL) {
    tags.push(`<link rel="canonical" href="${T.esc(SITE_URL + pathname)}">`);
    tags.push(`<meta property="og:url" content="${T.esc(SITE_URL + pathname)}">`);
  }
  const org = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Nexomed Biomédica',
    description:
      'Equipos médicos, estudios diagnósticos, consumibles, capacitación especializada y mantenimiento preventivo y correctivo de equipos médicos.',
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: WHATSAPP_DISPLAY,
      contactType: 'customer service',
      availableLanguage: 'Spanish',
    },
  };
  if (SITE_URL) org.url = SITE_URL;
  const sameAs = Object.values(ctx.social);
  if (sameAs.length) org.sameAs = sameAs;
  tags.push(`<script type="application/ld+json">${jsonForHtml(org)}</script>`);
  return tags.join('\n  ');
}

export function renderPage(name, pathname, extra = {}) {
  const ctx = publicView(getState());
  return fill(view(name), {
    SEO: seo(ctx, pathname),
    HEADER: T.header(ctx),
    FOOTER: T.footer(ctx, new Date().getFullYear()),
    WA_FLOAT: T.waFloat(ctx.whatsapp),
    WA_GENERAL: T.esc(waLink(ctx.whatsapp, messages.general())),
    WHATSAPP: ctx.whatsapp,
    WA_ICON: brandIcon('whatsapp'),
    ...extra(ctx),
  });
}

export const renderHome = () =>
  renderPage('index.html', '/', (ctx) => ({
    SERVICES: ctx.categories.map((c) => T.serviceCard(c, ctx.whatsapp)).join(''),
    FILTERS: T.filters(ctx.categories),
    CATALOG: ctx.categories.map((c) => T.catalogGroup(c, ctx.whatsapp)).join(''),
    SOCIAL_CTA: (() => {
      const links = T.socialLinks(ctx.social, 'social social-light');
      return links ? `<div class="cta-social"><span>Síguenos</span>${links}</div>` : '';
    })(),
  }));

export const renderPrivacy = () => renderPage('aviso-de-privacidad.html', '/aviso-de-privacidad', () => ({}));
export const renderNotFound = () => renderPage('404.html', '/404', () => ({}));

export function robots() {
  const lines = ['User-agent: *', 'Disallow: /admin', 'Disallow: /api/', 'Allow: /'];
  if (SITE_URL) lines.push(`Sitemap: ${SITE_URL}/sitemap.xml`);
  return `${lines.join('\n')}\n`;
}

export function sitemap() {
  if (!SITE_URL) return null;
  const urls = ['/', '/aviso-de-privacidad']
    .map((p) => `  <url><loc>${T.esc(SITE_URL + p)}</loc></url>`)
    .join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}
