import express from 'express';
import path from 'node:path';
import { HOST, IS_PROD, PORT, PUBLIC_DIR, TRUST_PROXY, UPLOADS_DIR, DATA_DIR } from './config.js';
import { initStore } from './store.js';
import { getAdmin } from './auth.js';
import { HttpError } from './errors.js';
import { apiRouter } from './routes/api.js';
import { adminRouter } from './routes/admin.js';
import { renderHome, renderNotFound, renderPrivacy, robots, sitemap } from './render.js';

const app = express();
app.disable('x-powered-by');
if (TRUST_PROXY) app.set('trust proxy', 1);

app.use((req, res, next) => {
  res.set({
    'Content-Security-Policy':
      "default-src 'self'; img-src 'self' data: blob:; style-src 'self'; script-src 'self'; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'",
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'X-Frame-Options': 'DENY',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'Cross-Origin-Opener-Policy': 'same-origin',
  });
  if (IS_PROD) res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  if (req.path.startsWith('/admin') || req.path.startsWith('/api')) res.set('X-Robots-Tag', 'noindex, nofollow');
  next();
});

const html = (res, body, status = 200) => res.status(status).type('html').set('Cache-Control', 'no-cache').send(body);

app.get(['/', '/index.html'], (req, res) => html(res, renderHome()));
app.get('/aviso-de-privacidad', (req, res) => html(res, renderPrivacy()));
app.get('/robots.txt', (req, res) => res.type('text/plain').send(robots()));
app.get('/sitemap.xml', (req, res) => {
  const xml = sitemap();
  return xml ? res.type('application/xml').send(xml) : html(res, renderNotFound(), 404);
});

app.use('/api/admin', adminRouter);
app.use('/api', apiRouter);
app.use('/api', (req, res) => res.status(404).json({ error: 'Ruta no encontrada.' }));

app.use('/uploads', express.static(UPLOADS_DIR, { index: false, dotfiles: 'deny', maxAge: '365d', immutable: true }));
app.use(
  express.static(PUBLIC_DIR, {
    index: 'index.html',
    dotfiles: 'deny',
    setHeaders(res, file) {
      res.set('Cache-Control', file.endsWith('.html') ? 'no-cache' : `public, max-age=${IS_PROD ? 3600 : 0}`);
    },
  })
);

app.use((req, res) => {
  if (req.method === 'GET' || req.method === 'HEAD') return html(res, renderNotFound(), 404);
  res.status(404).json({ error: 'Ruta no encontrada.' });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  let status = err instanceof HttpError ? err.status : 500;
  let message = err instanceof HttpError ? err.message : 'Ocurrió un error interno. Intenta de nuevo.';
  if (err.type === 'entity.too.large') {
    status = 413;
    message = req.path.endsWith('/uploads') ? 'La imagen supera el tamaño máximo de 3 MB.' : 'La solicitud es demasiado grande.';
  } else if (err.type === 'entity.parse.failed') {
    status = 400;
    message = 'La solicitud no tiene un formato válido.';
  } else if (status === 500) {
    console.error(err);
  }
  if (req.path.startsWith('/api')) return res.status(status).json({ error: message, field: err.field });
  res.status(status).type('text').send(message);
});

await initStore();
app.listen(PORT, HOST, () => {
  const shown = HOST === '0.0.0.0' ? 'localhost' : HOST;
  console.log(`Nexomed Biomédica en http://${shown}:${PORT}`);
  console.log(`Panel de administración: http://${shown}:${PORT}/admin`);
  console.log(`Datos: ${path.relative(process.cwd(), DATA_DIR) || DATA_DIR}`);
  if (!getAdmin()) console.log('Aviso: aún no hay administrador. Ejecuta «npm run admin:crear».');
});
