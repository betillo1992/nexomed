// Persistencia del catálogo en el servidor: archivo JSON con escritura atómica,
// escrituras serializadas y respaldo automático antes de cada cambio.
import fs from 'node:fs/promises';
import path from 'node:path';
import { CATALOG_FILE, BACKUPS_DIR, UPLOADS_DIR, MAX_BACKUPS } from './config.js';
import { buildSeed } from './seed.js';

let state = null;
let queue = Promise.resolve();

export async function initStore() {
  try {
    state = JSON.parse(await fs.readFile(CATALOG_FILE, 'utf8'));
  } catch (err) {
    if (err.code !== 'ENOENT') throw new Error(`No se pudo leer ${CATALOG_FILE}: ${err.message}`);
    state = buildSeed();
    await writeAtomic(state);
    console.log('Catálogo inicial creado en', CATALOG_FILE);
  }
  await pruneOrphanUploads();
}

export const getState = () => state;

// Aplica un cambio sobre una copia; solo se publica si se guardó en disco.
export function mutate(change) {
  const run = queue.then(async () => {
    const draft = structuredClone(state);
    const result = await change(draft);
    draft.updatedAt = new Date().toISOString();
    await backupCurrent();
    await writeAtomic(draft);
    state = draft;
    return result;
  });
  queue = run.catch(() => {});
  return run;
}

async function writeAtomic(data) {
  const tmp = `${CATALOG_FILE}.${process.pid}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(data, null, 2), 'utf8');
  for (let attempt = 0; ; attempt++) {
    try {
      await fs.rename(tmp, CATALOG_FILE);
      return;
    } catch (err) {
      // En Windows el antivirus puede bloquear el archivo un instante.
      if (attempt >= 5 || !['EPERM', 'EBUSY', 'EACCES'].includes(err.code)) throw err;
      await new Promise((r) => setTimeout(r, 50 * (attempt + 1)));
    }
  }
}

async function backupCurrent() {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  try {
    await fs.copyFile(CATALOG_FILE, path.join(BACKUPS_DIR, `catalog-${stamp}.json`));
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
  }
  const files = (await fs.readdir(BACKUPS_DIR)).filter((f) => f.startsWith('catalog-')).sort();
  await Promise.all(files.slice(0, -MAX_BACKUPS).map((f) => fs.unlink(path.join(BACKUPS_DIR, f)).catch(() => {})));
}

const isReferenced = (url) => state.items.some((i) => i.image === url);

// Borra imágenes que ya no usa ningún elemento.
export async function removeImages(urls) {
  for (const url of new Set(urls.filter(Boolean))) {
    if (isReferenced(url)) continue;
    await fs.unlink(path.join(UPLOADS_DIR, path.basename(url))).catch(() => {});
  }
}

// Imágenes subidas pero nunca guardadas en un elemento (más de un día).
async function pruneOrphanUploads() {
  const dayAgo = Date.now() - 24 * 3600 * 1000;
  for (const file of await fs.readdir(UPLOADS_DIR)) {
    const full = path.join(UPLOADS_DIR, file);
    if (isReferenced(`/uploads/${file}`)) continue;
    const stat = await fs.stat(full).catch(() => null);
    if (stat && stat.mtimeMs < dayAgo) await fs.unlink(full).catch(() => {});
  }
}
