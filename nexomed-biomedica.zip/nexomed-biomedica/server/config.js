import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Variables de entorno opcionales desde .env (ver .env.example).
try {
  process.loadEnvFile(path.join(ROOT, '.env'));
} catch {
  // Sin archivo .env: se usan los valores por defecto.
}

const env = process.env;

export const IS_PROD = env.NODE_ENV === 'production';
export const PORT = Number(env.PORT) || 3000;
export const HOST = env.HOST || (IS_PROD ? '0.0.0.0' : '127.0.0.1');
export const TRUST_PROXY = env.TRUST_PROXY === '1' || env.TRUST_PROXY === 'true';
export const COOKIE_SECURE = env.COOKIE_SECURE ? env.COOKIE_SECURE === 'true' : IS_PROD;
export const SESSION_HOURS = Number(env.SESSION_HOURS) || 8;
export const SITE_URL = (env.SITE_URL || '').replace(/\/+$/, '');

export const PUBLIC_DIR = path.join(ROOT, 'public');
export const VIEWS_DIR = path.join(ROOT, 'views');
export const DATA_DIR = path.resolve(ROOT, env.DATA_DIR || 'data');
export const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
export const BACKUPS_DIR = path.join(DATA_DIR, 'backups');
export const CATALOG_FILE = path.join(DATA_DIR, 'catalog.json');
export const ADMIN_FILE = path.join(DATA_DIR, 'admin.json');
export const SECRET_FILE = path.join(DATA_DIR, '.session-secret');

export const MAX_BACKUPS = 30;
export const MAX_UPLOAD_BYTES = 3 * 1024 * 1024;

// Único canal de contacto: WhatsApp (México +52).
export const WHATSAPP_NUMBER = '524641765544';
export const WHATSAPP_DISPLAY = '+52 464 176 5544';

for (const dir of [DATA_DIR, UPLOADS_DIR, BACKUPS_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}
