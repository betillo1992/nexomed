import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { requireAdmin, csrfGuard } from '../auth.js';
import { getState, mutate, removeImages } from '../store.js';
import { adminView, collator, itemsOf, nextOrder, sameName, sortedCategories, uniqueSlug } from '../catalog.js';
import { idList, validateCategory, validateItem, validatePublished, validateSocial } from '../validation.js';
import { HttpError } from '../errors.js';
import { MAX_UPLOAD_BYTES, UPLOADS_DIR } from '../config.js';
import { normalize } from '../../public/js/templates.js';

export const adminRouter = express.Router();
const json = express.json({ limit: '64kb' });

adminRouter.use(requireAdmin, csrfGuard, (req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

const respond = (res, status = 200, extra = {}) => res.status(status).json({ ...extra, catalog: adminView(getState()) });

function findCategory(state, id) {
  const cat = state.categories.find((c) => c.id === id);
  if (!cat) throw new HttpError(404, 'La categoría no existe. Recarga el panel.', 'categoryId');
  return cat;
}

function findItem(state, id) {
  const item = state.items.find((i) => i.id === id);
  if (!item) throw new HttpError(404, 'El elemento no existe. Recarga el panel.');
  return item;
}

function assertUniqueItem(state, { name, categoryId }, selfId) {
  if (state.items.some((i) => i.categoryId === categoryId && i.id !== selfId && sameName(i.name, name))) {
    throw new HttpError(409, 'Ya existe un elemento con ese nombre en la categoría seleccionada.', 'name');
  }
}

function assertUniqueCategory(state, name, selfId) {
  if (state.categories.some((c) => c.id !== selfId && sameName(c.name, name))) {
    throw new HttpError(409, 'Ya existe una categoría con ese nombre.', 'name');
  }
}

const sameIdSet = (ids, list) => ids.length === list.length && new Set(ids).size === ids.length && list.every((x) => ids.includes(x.id));

adminRouter.get('/catalog', (req, res) => respond(res));

// ---------- Elementos ----------

adminRouter.post('/items', json, async (req, res) => {
  const data = validateItem(req.body);
  const item = await mutate((s) => {
    findCategory(s, data.categoryId);
    assertUniqueItem(s, data);
    const now = new Date().toISOString();
    const created = {
      id: crypto.randomUUID(),
      ...data,
      order: nextOrder(s.items.filter((i) => i.categoryId === data.categoryId)),
      createdAt: now,
      updatedAt: now,
    };
    s.items.push(created);
    return created;
  });
  respond(res, 201, { item });
});

adminRouter.put('/items/:id', json, async (req, res) => {
  const data = validateItem(req.body);
  let previousImage = null;
  const item = await mutate((s) => {
    const item = findItem(s, req.params.id);
    findCategory(s, data.categoryId);
    assertUniqueItem(s, data, item.id);
    if (item.categoryId !== data.categoryId) {
      item.order = nextOrder(s.items.filter((i) => i.categoryId === data.categoryId));
    }
    previousImage = item.image !== data.image ? item.image : null;
    Object.assign(item, data, { updatedAt: new Date().toISOString() });
    return item;
  });
  await removeImages([previousImage]);
  respond(res, 200, { item });
});

adminRouter.patch('/items/:id/published', json, async (req, res) => {
  const published = validatePublished(req.body);
  await mutate((s) => {
    const item = findItem(s, req.params.id);
    item.published = published;
    item.updatedAt = new Date().toISOString();
  });
  respond(res);
});

adminRouter.delete('/items/:id', async (req, res) => {
  const removed = await mutate((s) => {
    const item = findItem(s, req.params.id);
    s.items = s.items.filter((i) => i.id !== item.id);
    return item;
  });
  await removeImages([removed.image]);
  respond(res);
});

// ---------- Orden de elementos ----------

adminRouter.post('/categories/:id/order', json, async (req, res) => {
  const ids = idList(req.body?.itemIds, 'elementos');
  await mutate((s) => {
    const cat = findCategory(s, req.params.id);
    const items = s.items.filter((i) => i.categoryId === cat.id);
    if (!sameIdSet(ids, items)) throw new HttpError(409, 'La lista cambió mientras la editabas. Recarga el panel.');
    ids.forEach((id, index) => {
      items.find((i) => i.id === id).order = index;
    });
    cat.sortMode = 'manual';
  });
  respond(res);
});

adminRouter.post('/categories/:id/sort-alpha', async (req, res) => {
  await mutate((s) => {
    const cat = findCategory(s, req.params.id);
    cat.sortMode = 'alpha';
    itemsOf(s, cat).forEach((item, index) => {
      item.order = index;
    });
  });
  respond(res);
});

// ---------- Categorías ----------

adminRouter.post('/categories', json, async (req, res) => {
  const data = validateCategory(req.body);
  const category = await mutate((s) => {
    assertUniqueCategory(s, data.name);
    const created = {
      id: crypto.randomUUID(),
      slug: uniqueSlug(s, data.name),
      ...data,
      sortMode: 'alpha',
      order: nextOrder(s.categories),
    };
    s.categories.push(created);
    return created;
  });
  respond(res, 201, { category });
});

adminRouter.put('/categories/:id', json, async (req, res) => {
  const data = validateCategory(req.body);
  await mutate((s) => {
    const cat = findCategory(s, req.params.id);
    assertUniqueCategory(s, data.name, cat.id);
    if (!sameName(cat.name, data.name)) cat.slug = uniqueSlug(s, data.name, cat.id);
    Object.assign(cat, data);
  });
  respond(res);
});

adminRouter.post('/categories/order', json, async (req, res) => {
  const ids = idList(req.body?.categoryIds, 'categorías');
  await mutate((s) => {
    if (!sameIdSet(ids, s.categories)) throw new HttpError(409, 'La lista cambió mientras la editabas. Recarga el panel.');
    ids.forEach((id, index) => {
      s.categories.find((c) => c.id === id).order = index;
    });
  });
  respond(res);
});

adminRouter.delete('/categories/:id', json, async (req, res) => {
  const { confirmName, itemsAction, targetCategoryId } = req.body || {};
  const removedImages = await mutate((s) => {
    const cat = findCategory(s, req.params.id);
    if (s.categories.length <= 1) throw new HttpError(400, 'Debe existir al menos una categoría.');
    if (typeof confirmName !== 'string' || normalize(confirmName) !== normalize(cat.name)) {
      throw new HttpError(400, 'Escribe el nombre exacto de la categoría para confirmar.', 'confirmName');
    }
    const items = s.items.filter((i) => i.categoryId === cat.id);
    let images = [];
    if (items.length) {
      if (itemsAction === 'move') {
        const target = findCategory(s, targetCategoryId);
        if (target.id === cat.id) throw new HttpError(400, 'Elige una categoría de destino diferente.', 'targetCategoryId');
        const clash = items.find((i) => s.items.some((t) => t.categoryId === target.id && sameName(t.name, i.name)));
        if (clash) {
          throw new HttpError(409, `«${clash.name}» ya existe en «${target.name}». Renómbralo o elimínalo antes de continuar.`);
        }
        let order = nextOrder(s.items.filter((i) => i.categoryId === target.id));
        for (const item of items.sort((a, b) => collator.compare(a.name, b.name))) {
          item.categoryId = target.id;
          item.order = order++;
        }
      } else if (itemsAction === 'delete') {
        images = items.map((i) => i.image);
        s.items = s.items.filter((i) => i.categoryId !== cat.id);
      } else {
        throw new HttpError(400, 'Indica qué hacer con los elementos de esta categoría.', 'itemsAction');
      }
    }
    s.categories = s.categories.filter((c) => c.id !== cat.id);
    sortedCategories(s).forEach((c, index) => {
      c.order = index;
    });
    return images;
  });
  await removeImages(removedImages);
  respond(res);
});

// ---------- Ajustes (redes sociales) ----------

adminRouter.put('/settings', json, async (req, res) => {
  const social = validateSocial(req.body?.social);
  await mutate((s) => {
    s.settings.social = social;
  });
  respond(res);
});

// ---------- Imágenes ----------

function detectImage(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.length > 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.length > 12 && buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  return null;
}

adminRouter.post('/uploads', express.raw({ type: () => true, limit: MAX_UPLOAD_BYTES }), async (req, res) => {
  if (!Buffer.isBuffer(req.body) || !req.body.length) throw new HttpError(400, 'No se recibió ninguna imagen.', 'image');
  const ext = detectImage(req.body);
  if (!ext) throw new HttpError(415, 'Formato no admitido. Usa una imagen JPG, PNG o WebP.', 'image');
  const name = `${crypto.randomUUID()}.${ext}`;
  await fs.writeFile(path.join(UPLOADS_DIR, name), req.body);
  res.status(201).json({ url: `/uploads/${name}` });
});

// ---------- Respaldo ----------

adminRouter.get('/export', (req, res) => {
  const date = new Date().toISOString().slice(0, 10);
  res.set('Content-Disposition', `attachment; filename="nexomed-catalogo-${date}.json"`);
  res.type('application/json').send(JSON.stringify(getState(), null, 2));
});
