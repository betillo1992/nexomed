import express from 'express';
import { getState } from '../store.js';
import { publicView } from '../catalog.js';
import { checkCredentials, clearSession, csrfGuard, getAdmin, issueSession, loginLimiter, readSession } from '../auth.js';

export const apiRouter = express.Router();
const json = express.json({ limit: '10kb' });

apiRouter.get('/catalog', (req, res) => {
  res.set('Cache-Control', 'no-cache');
  res.json(publicView(getState()));
});

apiRouter.get('/auth/me', (req, res) => {
  res.set('Cache-Control', 'no-store');
  const session = readSession(req);
  res.json({ configured: Boolean(getAdmin()), authenticated: Boolean(session), username: session?.username ?? null });
});

apiRouter.post('/auth/login', json, csrfGuard, async (req, res) => {
  const ip = req.ip;
  const wait = loginLimiter.retryAfter(ip);
  if (wait) {
    res.set('Retry-After', String(wait));
    return res.status(429).json({ error: `Demasiados intentos fallidos. Intenta de nuevo en ${Math.ceil(wait / 60)} min.` });
  }
  if (!getAdmin()) {
    return res.status(503).json({
      error: 'El acceso administrativo aún no está configurado. Ejecuta «npm run admin:crear» en el servidor.',
    });
  }
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string' || !username.trim() || !password || password.length > 256) {
    return res.status(400).json({ error: 'Escribe tu usuario y contraseña.' });
  }
  const { admin, ok } = await checkCredentials(username, password);
  if (!ok) {
    loginLimiter.fail(ip);
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
  }
  loginLimiter.reset(ip);
  issueSession(res, admin);
  res.json({ username: admin.username });
});

apiRouter.post('/auth/logout', csrfGuard, (req, res) => {
  clearSession(res);
  res.json({ ok: true });
});
