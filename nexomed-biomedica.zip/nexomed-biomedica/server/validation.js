import { HttpError } from './errors.js';
import { CATEGORY_ICON_KEYS } from '../public/js/icons.js';

const CONTROL_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
export const IMAGE_PATH = /^\/uploads\/[a-f0-9-]{36}\.(?:jpg|png|webp)$/;

export function text(value, { field, label, min = 0, max, multiline = false, required = false }) {
  if (value === undefined || value === null) value = '';
  if (typeof value !== 'string') throw new HttpError(400, `El campo «${label}» no tiene un formato válido.`, field);
  let v = value.replace(CONTROL_CHARS, '');
  v = multiline
    ? v
        .replace(/\r\n?/g, '\n')
        .split('\n')
        .map((line) => line.replace(/[ \t]+/g, ' ').trim())
        .join('\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim()
    : v.replace(/\s+/g, ' ').trim();
  if (required && !v) throw new HttpError(400, `Completa el campo «${label}».`, field);
  if (v && v.length < min) throw new HttpError(400, `«${label}» debe tener al menos ${min} caracteres.`, field);
  if (v.length > max) throw new HttpError(400, `«${label}» admite como máximo ${max} caracteres.`, field);
  return v;
}

function bool(value, label, field, fallback) {
  if (value === undefined) return fallback;
  if (typeof value !== 'boolean') throw new HttpError(400, `El campo «${label}» no es válido.`, field);
  return value;
}

export function imagePath(value) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value !== 'string' || !IMAGE_PATH.test(value)) {
    throw new HttpError(400, 'La imagen no es válida. Vuelve a subirla.', 'image');
  }
  return value;
}

export function validateItem(body = {}) {
  return {
    name: text(body.name, { field: 'name', label: 'Nombre', min: 2, max: 120, required: true }),
    description: text(body.description, { field: 'description', label: 'Descripción', max: 600, multiline: true }),
    categoryId: text(body.categoryId, { field: 'categoryId', label: 'Categoría', max: 64, required: true }),
    image: imagePath(body.image),
    published: bool(body.published, 'Publicado', 'published', true),
  };
}

export function validatePublished(body = {}) {
  if (typeof body.published !== 'boolean') throw new HttpError(400, 'Indica si el elemento debe publicarse.');
  return body.published;
}

export function validateCategory(body = {}) {
  const name = text(body.name, { field: 'name', label: 'Nombre', min: 2, max: 80, required: true });
  const shortName = text(body.shortName, { field: 'shortName', label: 'Nombre corto (menú)', max: 30 }) || name.slice(0, 30);
  const description = text(body.description, { field: 'description', label: 'Descripción', max: 400, multiline: true });
  const iconKey = body.icon === undefined ? 'stethoscope' : body.icon;
  if (!CATEGORY_ICON_KEYS.includes(iconKey)) throw new HttpError(400, 'Selecciona un icono válido.', 'icon');
  return { name, shortName, description, icon: iconKey };
}

const SOCIAL_RULES = {
  facebook: { label: 'Facebook', domains: ['facebook.com', 'fb.com'] },
  instagram: { label: 'Instagram', domains: ['instagram.com'] },
  tiktok: { label: 'TikTok', domains: ['tiktok.com'] },
};

export function validateSocial(body = {}) {
  const result = {};
  for (const [key, rule] of Object.entries(SOCIAL_RULES)) {
    const raw = text(body[key], { field: key, label: rule.label, max: 300 });
    if (!raw) {
      result[key] = '';
      continue;
    }
    let url;
    try {
      url = new URL(raw);
    } catch {
      throw new HttpError(400, `Escribe la dirección completa de ${rule.label}, comenzando con https://`, key);
    }
    const host = url.hostname.toLowerCase();
    if (url.protocol !== 'https:') throw new HttpError(400, `La dirección de ${rule.label} debe comenzar con https://`, key);
    if (!rule.domains.some((d) => host === d || host.endsWith(`.${d}`))) {
      throw new HttpError(400, `La dirección de ${rule.label} debe pertenecer a ${rule.domains[0]}.`, key);
    }
    if (url.pathname.replace(/\/+$/, '') === '' && !url.search) {
      throw new HttpError(400, `Incluye la ruta del perfil de ${rule.label}, no solo el dominio.`, key);
    }
    if (url.username || url.password) throw new HttpError(400, `La dirección de ${rule.label} no es válida.`, key);
    result[key] = url.toString();
  }
  return result;
}

export function idList(value, label) {
  if (!Array.isArray(value) || value.some((v) => typeof v !== 'string')) {
    throw new HttpError(400, `La lista de ${label} no es válida.`);
  }
  return value;
}

export function slugify(value) {
  return (
    String(value)
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 60) || 'categoria'
  );
}
