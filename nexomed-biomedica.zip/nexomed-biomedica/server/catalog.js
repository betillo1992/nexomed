// Reglas de orden y vistas (pública y administrativa) del catálogo.
import { WHATSAPP_NUMBER } from './config.js';
import { slugify } from './validation.js';

export const collator = new Intl.Collator('es-MX', { sensitivity: 'base', numeric: true });

export const sameName = (a, b) => collator.compare(a, b) === 0;

export function sortedCategories(state) {
  return [...state.categories].sort((a, b) => a.order - b.order || collator.compare(a.name, b.name));
}

// Orden alfabético por defecto; orden manual cuando la categoría lo indica.
export function itemsOf(state, category, { publishedOnly = false } = {}) {
  const list = state.items.filter((i) => i.categoryId === category.id && (!publishedOnly || i.published));
  const byName = (a, b) => collator.compare(a.name, b.name);
  return list.sort(category.sortMode === 'manual' ? (a, b) => a.order - b.order || byName(a, b) : byName);
}

export function nextOrder(list) {
  return list.reduce((max, x) => Math.max(max, x.order ?? -1), -1) + 1;
}

export function uniqueSlug(state, name, selfId) {
  const base = slugify(name);
  let slug = base;
  for (let n = 2; state.categories.some((c) => c.slug === slug && c.id !== selfId); n++) slug = `${base}-${n}`;
  return slug;
}

export function activeSocial(social = {}) {
  return Object.fromEntries(Object.entries(social).filter(([, url]) => typeof url === 'string' && url));
}

export function publicView(state) {
  return {
    whatsapp: WHATSAPP_NUMBER,
    social: activeSocial(state.settings.social),
    categories: sortedCategories(state).map((c) => ({
      id: c.id,
      slug: c.slug,
      name: c.name,
      shortName: c.shortName,
      description: c.description,
      icon: c.icon,
      items: itemsOf(state, c, { publishedOnly: true }).map(({ id, name, description, image }) => ({
        id,
        name,
        description,
        image,
      })),
    })),
  };
}

export function adminView(state) {
  return {
    updatedAt: state.updatedAt,
    settings: state.settings,
    categories: sortedCategories(state).map((c) => ({ ...c, items: itemsOf(state, c) })),
  };
}
