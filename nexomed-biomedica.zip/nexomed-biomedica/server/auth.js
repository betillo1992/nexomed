// Autenticación del panel: contraseña con hash scrypt guardada en el servidor,
// sesión en cookie firmada (HttpOnly, SameSite=Strict) y protección CSRF.
import crypto from 'node:crypto';
import fs from 'node:fs';
import { promisify } from 'node:util';
import { ADMIN_FILE, SECRET_FILE, COOKIE_SECURE, SESSION_HOURS } from './config.js';

const scrypt = promisify(crypto.scrypt);
const PARAMS = { N: 2 ** 17, r: 8, p: 1 };
const MAXMEM = 256 * 1024 * 1024;
const COOKIE = 'nx_admin';
const COOKIE_OPTS = { httpOnly: true, sameSite: 'strict', secure: COOKIE_SECURE, path: '/api' };

export async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password.normalize('NFKC'), salt, 64, { ...PARAMS, maxmem: MAXMEM });
  return ['scrypt', PARAMS.N, PARAMS.r, PARAMS.p, salt.toString('base64url'), key.toString('base64url')].join('$');
}

export async function verifyPassword(password, stored) {
  const parts = String(stored || '').split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [, N, r, p, salt, hash] = parts;
  const expected = Buffer.from(hash, 'base64url');
  const key = await scrypt(password.normalize('NFKC'), Buffer.from(salt, 'base64url'), expected.length, {
    N: Number(N),
    r: Number(r),
    p: Number(p),
    maxmem: MAXMEM,
  });
  return crypto.timingSafeEqual(key, expected);
}

// Credenciales: variables de entorno (hosting) o data/admin.json (npm run admin:crear).
export function getAdmin() {
  const { ADMIN_USERNAME, ADMIN_PASSWORD_HASH } = process.env;
  if (ADMIN_USERNAME && ADMIN_PASSWORD_HASH) {
    return { username: ADMIN_USERNAME.toLowerCase(), passwordHash: ADMIN_PASSWORD_HASH };
  }
  try {
    const admin = JSON.parse(fs.readFileSync(ADMIN_FILE, 'utf8'));
    if (admin.username && admin.passwordHash) return admin;
  } catch {
    // Sin administrador configurado.
  }
  return null;
}

let secret;
function getSecret() {
  if (secret) return secret;
  const fromEnv = process.env.SESSION_SECRET;
  if (fromEnv && fromEnv.length >= 32) return (secret = Buffer.from(fromEnv));
  try {
    const saved = Buffer.from(fs.readFileSync(SECRET_FILE, 'utf8').trim(), 'hex');
    if (saved.length >= 32) return (secret = saved);
  } catch {
    // Se genera a continuación.
  }
  secret = crypto.randomBytes(48);
  fs.writeFileSync(SECRET_FILE, secret.toString('hex'), { mode: 0o600 });
  return secret;
}

const sign = (data) => crypto.createHmac('sha256', getSecret()).update(data).digest('base64url');

// Cambiar la contraseña invalida todas las sesiones abiertas.
const fingerprint = (admin) =>
  crypto.createHash('sha256').update(`${admin.username}|${admin.passwordHash}`).digest('base64url').slice(0, 22);

function safeEqual(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function issueSession(res, admin) {
  const maxAge = SESSION_HOURS * 3600 * 1000;
  const payload = Buffer.from(JSON.stringify({ u: admin.username, f: fingerprint(admin), exp: Date.now() + maxAge })).toString(
    'base64url'
  );
  res.cookie(COOKIE, `${payload}.${sign(payload)}`, { ...COOKIE_OPTS, maxAge });
}

export function clearSession(res) {
  res.clearCookie(COOKIE, COOKIE_OPTS);
}

export function readSession(req) {
  const raw = parseCookies(req.headers.cookie)[COOKIE];
  if (!raw) return null;
  const [payload, signature] = raw.split('.');
  if (!payload || !signature || !safeEqual(signature, sign(payload))) return null;
  let data;
  try {
    data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
  if (!data.exp || data.exp < Date.now()) return null;
  const admin = getAdmin();
  if (!admin || admin.username !== data.u || fingerprint(admin) !== data.f) return null;
  return { username: data.u, expiresAt: data.exp };
}

export function requireAdmin(req, res, next) {
  const session = readSession(req);
  if (!session) return res.status(401).json({ error: 'Tu sesión expiró o no has iniciado sesión.' });
  req.admin = session;
  next();
}

// Las peticiones que modifican datos deben venir del propio panel.
export function csrfGuard(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('x-nexomed-admin') !== '1') return res.status(403).json({ error: 'Solicitud no permitida.' });
  const origin = req.get('origin');
  if (origin) {
    let host = '';
    try {
      host = new URL(origin).host;
    } catch {
      // Origen inválido.
    }
    if (host !== req.get('host')) return res.status(403).json({ error: 'Solicitud no permitida.' });
  }
  next();
}

// Límite de intentos fallidos por IP.
const WINDOW_MS = 15 * 60 * 1000;
const MAX_FAILURES = 5;
const failures = new Map();

export const loginLimiter = {
  retryAfter(ip) {
    const entry = failures.get(ip);
    if (!entry || Date.now() - entry.first > WINDOW_MS) return 0;
    return entry.count >= MAX_FAILURES ? Math.ceil((entry.first + WINDOW_MS - Date.now()) / 1000) : 0;
  },
  fail(ip) {
    const entry = failures.get(ip);
    if (!entry || Date.now() - entry.first > WINDOW_MS) failures.set(ip, { count: 1, first: Date.now() });
    else entry.count++;
    if (failures.size > 5000) failures.clear();
  },
  reset(ip) {
    failures.delete(ip);
  },
};

export async function checkCredentials(username, password) {
  const admin = getAdmin();
  if (!admin) return { admin: null, ok: false };
  const userOk = safeEqual(username.trim().toLowerCase(), admin.username);
  // La contraseña siempre se verifica para no revelar si el usuario existe.
  const passOk = await verifyPassword(password, admin.passwordHash);
  return { admin, ok: userOk && passOk };
}
