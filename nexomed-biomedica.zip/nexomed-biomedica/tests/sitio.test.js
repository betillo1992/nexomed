// Pruebas de extremo a extremo contra un servidor real con datos temporales.
//   npm test
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn, execFileSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'nexomed-test-'));
const PORT = 3200 + Math.floor(Math.random() * 500);
const BASE = `http://127.0.0.1:${PORT}`;
const USER = 'pruebas';
const PASS = 'Clave-de-prueba-larga-2026';
const env = { ...process.env, DATA_DIR, PORT: String(PORT), NODE_ENV: 'test' };

let server;
let cookie = '';

async function startServer() {
  server = spawn(process.execPath, ['server/index.js'], { cwd: ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] });
  server.stderr.on('data', (d) => process.stderr.write(d));
  for (let i = 0; i < 50; i++) {
    try {
      await fetch(`${BASE}/robots.txt`);
      return;
    } catch {
      await new Promise((r) => setTimeout(r, 100));
    }
  }
  throw new Error('El servidor no arrancó');
}

async function stopServer() {
  if (!server) return;
  const exited = new Promise((r) => server.once('exit', r));
  server.kill();
  await exited;
}

const admin = (url, { method = 'GET', body, headers = {} } = {}) =>
  fetch(`${BASE}${url}`, {
    method,
    headers: { 'X-Nexomed-Admin': '1', cookie, ...(body !== undefined && { 'Content-Type': 'application/json' }), ...headers },
    body: body === undefined ? undefined : typeof body === 'string' || body instanceof Uint8Array ? body : JSON.stringify(body),
  });

const page = async (url = '/') => (await fetch(`${BASE}${url}`)).text();
const catByName = (catalog, name) => catalog.categories.find((c) => c.name === name);
const decode = (s) => s.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');

function groupItemNames(html, slug) {
  const start = html.indexOf(`id="cat-${slug}"`);
  const end = html.indexOf('</section>', start);
  return [...html.slice(start, end).matchAll(/<h4 class="item-name">([^<]+)<\/h4>/g)].map((m) => decode(m[1]));
}

before(async () => {
  execFileSync(process.execPath, ['scripts/crear-admin.js'], {
    cwd: ROOT,
    env: { ...env, ADMIN_USERNAME: USER, ADMIN_PASSWORD: PASS },
    stdio: 'ignore',
  });
  await startServer();
});

after(async () => {
  await stopServer();
  fs.rmSync(DATA_DIR, { recursive: true, force: true });
});

test('la portada muestra las cinco categorías en orden alfabético', async () => {
  const html = await page('/');
  assert.match(html, /Soluciones integrales en tecnología médica/);
  assert.deepEqual(groupItemNames(html, 'equipos-medicos'), [
    'Baumanómetro',
    'Concentradores de oxígeno',
    'CPAP',
    'Electrocardiógrafo',
    'Monitor de signos vitales',
    'Oxímetro',
    'Termómetro',
  ]);
  assert.deepEqual(groupItemNames(html, 'estudios-diagnosticos'), [
    'Electrocardiograma',
    'Electroencefalograma',
    'Espirometría',
    'Holter',
    'Monitoreo Ambulatorio de la Presión Arterial (MAPA)',
  ]);
  assert.deepEqual(groupItemNames(html, 'consumibles'), ['Cal sodada', 'Gel conductor', 'Papel para electrocardiograma']);
  assert.deepEqual(groupItemNames(html, 'capacitacion'), [
    'Autoclaves',
    'Bombas de infusión',
    'Desfibriladores',
    'Electrocardiogramas',
    'Electrocauterios',
    'Máquinas de anestesia',
    'Monitores de signos vitales',
  ]);
  assert.deepEqual(groupItemNames(html, 'mantenimiento'), [
    'Autoclaves',
    'Camas hospitalarias',
    'Concentradores de oxígeno',
    'Lámparas de quirófano',
    'Monitores de signos vitales',
  ]);
  assert.match(html, /realizados por personal biomédico\. Incluimos la identificación y el etiquetado/);
});

test('los botones generan enlaces de WhatsApp correctos y codificados', async () => {
  const html = await page('/');
  const links = [...html.matchAll(/href="(https:\/\/wa\.me\/[^"]+)"/g)].map((m) => decode(m[1]));
  assert.ok(links.length > 30, `se esperaban muchos enlaces, hay ${links.length}`);
  for (const link of links) assert.match(link, /^https:\/\/wa\.me\/524641765544(\?text=[^\s]+)?$/);
  const expected =
    'https://wa.me/524641765544?text=' +
    encodeURIComponent(
      'Hola, Nexomed Biomédica. Me interesa obtener información sobre «Monitor de signos vitales» (categoría: Equipos médicos). ¿Podrían proporcionarme más detalles?'
    );
  assert.ok(links.includes(expected), 'falta el enlace del monitor de signos vitales');
  assert.match(html, /class="wa-float"/);
  assert.match(html, /class="btn btn-primary btn-sm header-wa"/);
});

test('no hay canales de correo ni redes sociales sin configurar', async () => {
  for (const url of ['/', '/aviso-de-privacidad']) {
    const html = await page(url);
    assert.doesNotMatch(html, /mailto:/i);
    assert.doesNotMatch(html, /[\w.+-]+@[\w-]+\.[a-z]{2,}/i, 'no debe haber direcciones de correo');
    assert.doesNotMatch(html, /newsletter|boletín/i);
    assert.doesNotMatch(html, /facebook\.com|instagram\.com|tiktok\.com/i);
    assert.doesNotMatch(html, /<form/i);
  }
});

test('páginas auxiliares: aviso de privacidad, 404, robots', async () => {
  assert.equal((await fetch(`${BASE}/aviso-de-privacidad`)).status, 200);
  const missing = await fetch(`${BASE}/no-existe`);
  assert.equal(missing.status, 404);
  assert.match(await missing.text(), /No encontramos esta página/);
  assert.match(await page('/robots.txt'), /Disallow: \/admin/);
  const adminPage = await fetch(`${BASE}/admin/`);
  assert.equal(adminPage.status, 200);
  assert.equal(adminPage.headers.get('x-robots-tag'), 'noindex, nofollow');
  assert.match(adminPage.headers.get('content-security-policy'), /script-src 'self'/);
});

test('el panel exige autenticación y protección CSRF', async () => {
  assert.equal((await fetch(`${BASE}/api/admin/catalog`)).status, 401);
  const noHeader = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: USER, password: PASS }),
  });
  assert.equal(noHeader.status, 403);
  const wrong = await admin('/api/auth/login', { method: 'POST', body: { username: USER, password: 'incorrecta-123456' } });
  assert.equal(wrong.status, 401);
  const forged = await fetch(`${BASE}/api/admin/catalog`, { headers: { cookie: 'nx_admin=eyJ1IjoicHJ1ZWJhcyJ9.firma-falsa' } });
  assert.equal(forged.status, 401);

  const ok = await admin('/api/auth/login', { method: 'POST', body: { username: 'PRUEBAS', password: PASS } });
  assert.equal(ok.status, 200);
  const setCookie = ok.headers.get('set-cookie');
  assert.match(setCookie, /HttpOnly/i);
  assert.match(setCookie, /SameSite=Strict/i);
  cookie = setCookie.split(';')[0];

  const crossSite = await admin('/api/admin/items', { method: 'POST', body: {}, headers: { origin: 'https://sitio-ajeno.example' } });
  assert.equal(crossSite.status, 403);
  const me = await (await admin('/api/auth/me')).json();
  assert.equal(me.authenticated, true);
});

let catalog;
let itemId;

test('agregar, validar, editar y mover elementos', async () => {
  catalog = (await (await admin('/api/admin/catalog')).json()).catalog;
  const equipos = catByName(catalog, 'Equipos médicos');
  const consumibles = catByName(catalog, 'Consumibles');

  const invalid = await admin('/api/admin/items', { method: 'POST', body: { name: 'A', categoryId: equipos.id } });
  assert.equal(invalid.status, 400);
  assert.equal((await invalid.json()).field, 'name');

  const dup = await admin('/api/admin/items', { method: 'POST', body: { name: 'oximetro', categoryId: equipos.id } });
  assert.equal(dup.status, 409, 'los duplicados se comparan sin acentos ni mayúsculas');

  const created = await admin('/api/admin/items', {
    method: 'POST',
    body: { name: '  Aspirador   de secreciones ', categoryId: equipos.id, description: 'Elemento de prueba', published: true },
  });
  assert.equal(created.status, 201);
  const body = await created.json();
  itemId = body.item.id;
  assert.equal(body.item.name, 'Aspirador de secreciones');
  assert.deepEqual(
    catByName(body.catalog, 'Equipos médicos').items.slice(0, 2).map((i) => i.name),
    ['Aspirador de secreciones', 'Baumanómetro'],
    'un elemento nuevo se acomoda alfabéticamente'
  );
  assert.match(await page('/'), /Aspirador de secreciones/);

  const edited = await admin(`/api/admin/items/${itemId}`, {
    method: 'PUT',
    body: { name: 'Electrodos', categoryId: consumibles.id, description: 'Movido', published: true },
  });
  assert.equal(edited.status, 200);
  const after = (await edited.json()).catalog;
  assert.ok(catByName(after, 'Consumibles').items.some((i) => i.name === 'Electrodos'));
  assert.ok(!catByName(after, 'Equipos médicos').items.some((i) => i.id === itemId));
});

test('ocultar un elemento lo retira del sitio sin borrarlo', async () => {
  const res = await admin(`/api/admin/items/${itemId}/published`, { method: 'PATCH', body: { published: false } });
  assert.equal(res.status, 200);
  const pub = await (await fetch(`${BASE}/api/catalog`)).json();
  assert.ok(!catByName(pub, 'Consumibles').items.some((i) => i.id === itemId));
  assert.doesNotMatch(await page('/'), /Electrodos/);
  const all = (await res.json()).catalog;
  assert.ok(catByName(all, 'Consumibles').items.some((i) => i.id === itemId && !i.published));
  await admin(`/api/admin/items/${itemId}/published`, { method: 'PATCH', body: { published: true } });
});

test('orden manual y regreso al orden alfabético', async () => {
  catalog = (await (await admin('/api/admin/catalog')).json()).catalog;
  const cat = catByName(catalog, 'Consumibles');
  const ids = cat.items.map((i) => i.id).reverse();
  const manual = await admin(`/api/admin/categories/${cat.id}/order`, { method: 'POST', body: { itemIds: ids } });
  assert.equal(manual.status, 200);
  const reordered = catByName((await manual.json()).catalog, 'Consumibles');
  assert.equal(reordered.sortMode, 'manual');
  assert.deepEqual(reordered.items.map((i) => i.id), ids);
  assert.deepEqual(groupItemNames(await page('/'), 'consumibles'), reordered.items.map((i) => i.name));

  const bad = await admin(`/api/admin/categories/${cat.id}/order`, { method: 'POST', body: { itemIds: ids.slice(1) } });
  assert.equal(bad.status, 409);

  const alpha = await admin(`/api/admin/categories/${cat.id}/sort-alpha`, { method: 'POST' });
  const sorted = catByName((await alpha.json()).catalog, 'Consumibles');
  assert.equal(sorted.sortMode, 'alpha');
  assert.deepEqual(sorted.items.map((i) => i.name), ['Cal sodada', 'Electrodos', 'Gel conductor', 'Papel para electrocardiograma']);
});

test('imágenes: solo formatos válidos y se sirven correctamente', async () => {
  const png = Buffer.from(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
    'base64'
  );
  const up = await admin('/api/admin/uploads', { method: 'POST', body: png, headers: { 'Content-Type': 'image/png' } });
  assert.equal(up.status, 201);
  const { url } = await up.json();
  assert.match(url, /^\/uploads\/[a-f0-9-]{36}\.png$/);

  const fake = await admin('/api/admin/uploads', { method: 'POST', body: '<script>alert(1)</script>', headers: { 'Content-Type': 'image/png' } });
  assert.equal(fake.status, 415);

  const cat = catByName(catalog, 'Consumibles');
  const withImage = await admin(`/api/admin/items/${itemId}`, {
    method: 'PUT',
    body: { name: 'Electrodos', categoryId: cat.id, description: 'Movido', image: url, published: true },
  });
  assert.equal(withImage.status, 200);
  const img = await fetch(`${BASE}${url}`);
  assert.equal(img.status, 200);
  assert.equal(img.headers.get('content-type'), 'image/png');
  assert.match(await page('/'), new RegExp(`<img src="${url}"`));

  const badPath = await admin(`/api/admin/items/${itemId}`, {
    method: 'PUT',
    body: { name: 'Electrodos', categoryId: cat.id, image: 'https://otro-sitio.example/x.png' },
  });
  assert.equal(badPath.status, 400);
});

test('categorías: crear, editar y eliminar moviendo sus elementos', async () => {
  const created = await admin('/api/admin/categories', {
    method: 'POST',
    body: { name: 'Refacciones', shortName: 'Refacciones', description: 'Categoría de prueba', icon: 'package' },
  });
  assert.equal(created.status, 201);
  const cat = (await created.json()).category;
  assert.equal(cat.slug, 'refacciones');

  const renamed = await admin(`/api/admin/categories/${cat.id}`, {
    method: 'PUT',
    body: { name: 'Refacciones médicas', shortName: 'Refacciones', description: 'Editada', icon: 'wrench' },
  });
  assert.equal(renamed.status, 200);

  await admin('/api/admin/items', { method: 'POST', body: { name: 'Sensor de oximetría', categoryId: cat.id } });
  let html = await page('/');
  assert.match(html, /id="cat-refacciones-medicas"/);
  assert.match(html, /data-nav="refacciones-medicas">Refacciones</);

  const noConfirm = await admin(`/api/admin/categories/${cat.id}`, {
    method: 'DELETE',
    body: { confirmName: 'otra', itemsAction: 'move', targetCategoryId: catalog.categories[0].id },
  });
  assert.equal(noConfirm.status, 400);
  const noAction = await admin(`/api/admin/categories/${cat.id}`, { method: 'DELETE', body: { confirmName: 'Refacciones médicas' } });
  assert.equal(noAction.status, 400, 'no se borra si no se indica qué hacer con los elementos');

  const target = catByName(catalog, 'Equipos médicos');
  const del = await admin(`/api/admin/categories/${cat.id}`, {
    method: 'DELETE',
    body: { confirmName: 'refacciones medicas', itemsAction: 'move', targetCategoryId: target.id },
  });
  assert.equal(del.status, 200);
  const after = (await del.json()).catalog;
  assert.equal(after.categories.length, 5);
  assert.ok(catByName(after, 'Equipos médicos').items.some((i) => i.name === 'Sensor de oximetría'));
  html = await page('/');
  assert.doesNotMatch(html, /cat-refacciones-medicas/);
});

test('redes sociales: validación y aparición solo cuando están configuradas', async () => {
  const wrong = await admin('/api/admin/settings', { method: 'PUT', body: { social: { facebook: 'https://sitio-falso.example/nexomed' } } });
  assert.equal(wrong.status, 400);
  assert.equal((await wrong.json()).field, 'facebook');
  const http = await admin('/api/admin/settings', { method: 'PUT', body: { social: { instagram: 'http://instagram.com/x' } } });
  assert.equal(http.status, 400);

  const ok = await admin('/api/admin/settings', {
    method: 'PUT',
    body: { social: { facebook: 'https://www.facebook.com/perfil-de-prueba', instagram: '', tiktok: '' } },
  });
  assert.equal(ok.status, 200);
  const html = await page('/');
  assert.match(html, /href="https:\/\/www\.facebook\.com\/perfil-de-prueba" target="_blank" rel="noopener noreferrer" aria-label="Facebook/);
  assert.doesNotMatch(html, /instagram\.com|tiktok\.com/);

  await admin('/api/admin/settings', { method: 'PUT', body: { social: { facebook: '', instagram: '', tiktok: '' } } });
  assert.doesNotMatch(await page('/'), /facebook\.com/);
});

test('eliminar un elemento', async () => {
  const del = await admin(`/api/admin/items/${itemId}`, { method: 'DELETE' });
  assert.equal(del.status, 200);
  assert.equal((await admin(`/api/admin/items/${itemId}`, { method: 'DELETE' })).status, 404);
  assert.doesNotMatch(await page('/'), /Electrodos/);
});

test('los cambios persisten tras reiniciar el servidor y se respaldan', async () => {
  await admin('/api/admin/items', { method: 'POST', body: { name: 'Elemento persistente', categoryId: catalog.categories[0].id } });
  await stopServer();
  await startServer();
  assert.match(await page('/'), /Elemento persistente/);
  assert.ok(fs.readdirSync(path.join(DATA_DIR, 'backups')).length > 0, 'debe haber respaldos automáticos');
  assert.equal((await admin('/api/admin/catalog')).status, 200, 'la sesión sigue siendo válida tras reiniciar');
});

test('cerrar sesión y límite de intentos fallidos', async () => {
  const out = await admin('/api/auth/logout', { method: 'POST' });
  assert.match(out.headers.get('set-cookie'), /nx_admin=;/);
  cookie = '';
  let last;
  for (let i = 0; i < 6; i++) {
    last = await admin('/api/auth/login', { method: 'POST', body: { username: USER, password: `mala-${i}-xxxxxxxx` } });
  }
  assert.equal(last.status, 429);
});
